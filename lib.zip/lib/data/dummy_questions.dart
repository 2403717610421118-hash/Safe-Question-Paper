import 'package:crypto/crypto.dart';
import '../models/question.dart';
import '../models/setter_profile.dart';

// ── Pre-defined setter profiles with deterministic key bytes ──────────────────
// Private keys are fixed for reproducibility in demos.
// Public key = SHA-256(private key)

final SetterProfile setterMath = _buildProfile(
  id: 'setter_math',
  name: 'Dr. Anjali Sharma',
  subjectCode: 'MATH',
  subjectName: 'Mathematics',
  privateKeyHex:
      'a3f1e2d4b5c6a7f8e1d2c3b4a5f6e7d8c1b2a3f4e5d6c7b8a9f0e1d2c3b4a5f6',
);

final SetterProfile setterCS = _buildProfile(
  id: 'setter_cs',
  name: 'Prof. Ravi Kumar',
  subjectCode: 'CS',
  subjectName: 'Computer Science',
  privateKeyHex:
      '1b2c3d4e5f6a7b8c9d0e1f2a3b4c5d6e7f8a9b0c1d2e3f4a5b6c7d8e9f0a1b2c',
);

final SetterProfile setterPhy = _buildProfile(
  id: 'setter_phy',
  name: 'Dr. Meera Nair',
  subjectCode: 'PHY',
  subjectName: 'Physics',
  privateKeyHex:
      'c4d5e6f7a8b9c0d1e2f3a4b5c6d7e8f9a0b1c2d3e4f5a6b7c8d9e0f1a2b3c4d5',
);

SetterProfile _buildProfile({
  required String id,
  required String name,
  required String subjectCode,
  required String subjectName,
  required String privateKeyHex,
}) {
  final privateKeyBytes = List.generate(
    32,
    (i) => int.parse(privateKeyHex.substring(i * 2, i * 2 + 2), radix: 16),
  );
  final publicKeyBytes = sha256.convert(privateKeyBytes).bytes;
  final fingerprint = List.generate(16, (i) => publicKeyBytes[i])
      .map((b) => b.toRadixString(16).padLeft(2, '0'))
      .toList()
      .asMap()
      .entries
      .map((e) => (e.key % 2 == 1) ? '${e.value}:' : e.value)
      .join()
      .trimRight()
      .replaceAll('::', ':')
      .toUpperCase();

  return SetterProfile(
    id: id,
    name: name,
    subjectCode: subjectCode,
    subjectName: subjectName,
    privateKeyBytes: privateKeyBytes,
    publicKeyBytes: publicKeyBytes,
    fingerprint: fingerprint,
  );
}

// ── Mathematics questions (15) ────────────────────────────────────────────────

final List<RawQuestion> mathQuestions = [
  RawQuestion(
    id: 'math_001', subjectCode: 'MATH', subjectName: 'Mathematics',
    topic: 'Calculus', difficulty: QuestionDifficulty.easy,
    setterId: setterMath.id, setterName: setterMath.name,
    text: 'What is the derivative of f(x) = x³ + 2x² − 5x + 7?',
    options: ['3x² + 4x − 5', '3x² + 2x − 5', 'x² + 4x', '3x² − 5'],
    correctAnswerIndex: 0,
  ),
  RawQuestion(
    id: 'math_002', subjectCode: 'MATH', subjectName: 'Mathematics',
    topic: 'Calculus', difficulty: QuestionDifficulty.medium,
    setterId: setterMath.id, setterName: setterMath.name,
    text: 'Evaluate the integral ∫(2x + 3) dx from 0 to 2.',
    options: ['8', '10', '7', '6'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'math_003', subjectCode: 'MATH', subjectName: 'Mathematics',
    topic: 'Calculus', difficulty: QuestionDifficulty.hard,
    setterId: setterMath.id, setterName: setterMath.name,
    text: 'Find the limit: lim(x→0) [sin(3x) / x].',
    options: ['0', '1', '3', 'Does not exist'],
    correctAnswerIndex: 2,
  ),
  RawQuestion(
    id: 'math_004', subjectCode: 'MATH', subjectName: 'Mathematics',
    topic: 'Algebra', difficulty: QuestionDifficulty.easy,
    setterId: setterMath.id, setterName: setterMath.name,
    text: 'What are the roots of the equation x² − 5x + 6 = 0?',
    options: ['x = 2, x = 3', 'x = −2, x = −3', 'x = 1, x = 6', 'x = −1, x = −6'],
    correctAnswerIndex: 0,
  ),
  RawQuestion(
    id: 'math_005', subjectCode: 'MATH', subjectName: 'Mathematics',
    topic: 'Algebra', difficulty: QuestionDifficulty.medium,
    setterId: setterMath.id, setterName: setterMath.name,
    text: 'If A = [[1, 2], [3, 4]], what is the determinant of A?',
    options: ['−2', '2', '10', '−10'],
    correctAnswerIndex: 0,
  ),
  RawQuestion(
    id: 'math_006', subjectCode: 'MATH', subjectName: 'Mathematics',
    topic: 'Algebra', difficulty: QuestionDifficulty.hard,
    setterId: setterMath.id, setterName: setterMath.name,
    text: 'Find the eigenvalues of the matrix [[3, 1], [1, 3]].',
    options: ['2 and 4', '1 and 5', '3 and 3', '0 and 6'],
    correctAnswerIndex: 0,
  ),
  RawQuestion(
    id: 'math_007', subjectCode: 'MATH', subjectName: 'Mathematics',
    topic: 'Statistics', difficulty: QuestionDifficulty.easy,
    setterId: setterMath.id, setterName: setterMath.name,
    text: 'The mean of the data set {4, 8, 15, 16, 23, 42} is:',
    options: ['16.5', '18', '17.3', '19'],
    correctAnswerIndex: 2,
  ),
  RawQuestion(
    id: 'math_008', subjectCode: 'MATH', subjectName: 'Mathematics',
    topic: 'Statistics', difficulty: QuestionDifficulty.medium,
    setterId: setterMath.id, setterName: setterMath.name,
    text: 'For a normal distribution, what percentage of data lies within 2 standard deviations of the mean?',
    options: ['68%', '95%', '99.7%', '50%'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'math_009', subjectCode: 'MATH', subjectName: 'Mathematics',
    topic: 'Statistics', difficulty: QuestionDifficulty.hard,
    setterId: setterMath.id, setterName: setterMath.name,
    text: 'A bag contains 5 red and 3 blue balls. Two balls are drawn without replacement. What is the probability both are red?',
    options: ['5/14', '25/64', '10/56', '5/28'],
    correctAnswerIndex: 0,
  ),
  RawQuestion(
    id: 'math_010', subjectCode: 'MATH', subjectName: 'Mathematics',
    topic: 'Geometry', difficulty: QuestionDifficulty.easy,
    setterId: setterMath.id, setterName: setterMath.name,
    text: 'The area of a circle with radius 7 cm is (use π = 22/7):',
    options: ['44 cm²', '154 cm²', '49 cm²', '308 cm²'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'math_011', subjectCode: 'MATH', subjectName: 'Mathematics',
    topic: 'Geometry', difficulty: QuestionDifficulty.medium,
    setterId: setterMath.id, setterName: setterMath.name,
    text: 'In a right triangle, if one leg is 5 and hypotenuse is 13, the other leg is:',
    options: ['8', '10', '11', '12'],
    correctAnswerIndex: 3,
  ),
  RawQuestion(
    id: 'math_012', subjectCode: 'MATH', subjectName: 'Mathematics',
    topic: 'Geometry', difficulty: QuestionDifficulty.hard,
    setterId: setterMath.id, setterName: setterMath.name,
    text: 'The volume of a sphere with radius r is:',
    options: ['4πr²', '(4/3)πr³', '(2/3)πr³', '2πr³'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'math_013', subjectCode: 'MATH', subjectName: 'Mathematics',
    topic: 'Calculus', difficulty: QuestionDifficulty.medium,
    setterId: setterMath.id, setterName: setterMath.name,
    text: 'The second derivative of f(x) = sin(x) is:',
    options: ['cos(x)', '−sin(x)', 'sin(x)', '−cos(x)'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'math_014', subjectCode: 'MATH', subjectName: 'Mathematics',
    topic: 'Algebra', difficulty: QuestionDifficulty.easy,
    setterId: setterMath.id, setterName: setterMath.name,
    text: 'Simplify: (2x³y²) × (3x²y)',
    options: ['5x⁵y³', '6x⁵y³', '6x⁶y²', '5x⁶y³'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'math_015', subjectCode: 'MATH', subjectName: 'Mathematics',
    topic: 'Statistics', difficulty: QuestionDifficulty.medium,
    setterId: setterMath.id, setterName: setterMath.name,
    text: 'What is the variance of {2, 4, 4, 4, 5, 5, 7, 9}?',
    options: ['2', '3', '4', '5'],
    correctAnswerIndex: 2,
  ),
];

// ── Computer Science questions (15) ──────────────────────────────────────────

final List<RawQuestion> csQuestions = [
  RawQuestion(
    id: 'cs_001', subjectCode: 'CS', subjectName: 'Computer Science',
    topic: 'Data Structures', difficulty: QuestionDifficulty.easy,
    setterId: setterCS.id, setterName: setterCS.name,
    text: 'Which data structure uses LIFO (Last In First Out) principle?',
    options: ['Queue', 'Stack', 'Linked List', 'Tree'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'cs_002', subjectCode: 'CS', subjectName: 'Computer Science',
    topic: 'Data Structures', difficulty: QuestionDifficulty.medium,
    setterId: setterCS.id, setterName: setterCS.name,
    text: 'What is the time complexity of searching in a balanced binary search tree?',
    options: ['O(1)', 'O(log n)', 'O(n)', 'O(n log n)'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'cs_003', subjectCode: 'CS', subjectName: 'Computer Science',
    topic: 'Data Structures', difficulty: QuestionDifficulty.hard,
    setterId: setterCS.id, setterName: setterCS.name,
    text: 'In a hash table with chaining, the worst-case time for a lookup is:',
    options: ['O(1)', 'O(log n)', 'O(n)', 'O(n²)'],
    correctAnswerIndex: 2,
  ),
  RawQuestion(
    id: 'cs_004', subjectCode: 'CS', subjectName: 'Computer Science',
    topic: 'Algorithms', difficulty: QuestionDifficulty.easy,
    setterId: setterCS.id, setterName: setterCS.name,
    text: 'Which sorting algorithm has the best average-case time complexity?',
    options: ['Bubble Sort', 'Merge Sort', 'Insertion Sort', 'Selection Sort'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'cs_005', subjectCode: 'CS', subjectName: 'Computer Science',
    topic: 'Algorithms', difficulty: QuestionDifficulty.medium,
    setterId: setterCS.id, setterName: setterCS.name,
    text: 'Dijkstra\'s algorithm is used to solve which class of problems?',
    options: ['Minimum Spanning Tree', 'Shortest Path', 'Maximum Flow', 'String Matching'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'cs_006', subjectCode: 'CS', subjectName: 'Computer Science',
    topic: 'Algorithms', difficulty: QuestionDifficulty.hard,
    setterId: setterCS.id, setterName: setterCS.name,
    text: 'What is the recurrence relation for Merge Sort?',
    options: ['T(n) = T(n-1) + O(n)', 'T(n) = 2T(n/2) + O(n)', 'T(n) = T(n/2) + O(1)', 'T(n) = 2T(n) + O(log n)'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'cs_007', subjectCode: 'CS', subjectName: 'Computer Science',
    topic: 'Operating Systems', difficulty: QuestionDifficulty.easy,
    setterId: setterCS.id, setterName: setterCS.name,
    text: 'Which scheduling algorithm is known to cause the "convoy effect"?',
    options: ['Round Robin', 'FCFS', 'SJF', 'Priority Scheduling'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'cs_008', subjectCode: 'CS', subjectName: 'Computer Science',
    topic: 'Operating Systems', difficulty: QuestionDifficulty.medium,
    setterId: setterCS.id, setterName: setterCS.name,
    text: 'Deadlock can be prevented by breaking which of the four necessary conditions?',
    options: ['Mutual Exclusion', 'Hold and Wait', 'Circular Wait', 'All of the above'],
    correctAnswerIndex: 3,
  ),
  RawQuestion(
    id: 'cs_009', subjectCode: 'CS', subjectName: 'Computer Science',
    topic: 'Operating Systems', difficulty: QuestionDifficulty.hard,
    setterId: setterCS.id, setterName: setterCS.name,
    text: 'In the Banker\'s algorithm, the "safe sequence" guarantees:',
    options: ['No starvation', 'No deadlock', 'Maximum throughput', 'Minimum waiting time'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'cs_010', subjectCode: 'CS', subjectName: 'Computer Science',
    topic: 'Networks', difficulty: QuestionDifficulty.easy,
    setterId: setterCS.id, setterName: setterCS.name,
    text: 'Which layer of the OSI model is responsible for routing?',
    options: ['Physical', 'Data Link', 'Network', 'Transport'],
    correctAnswerIndex: 2,
  ),
  RawQuestion(
    id: 'cs_011', subjectCode: 'CS', subjectName: 'Computer Science',
    topic: 'Networks', difficulty: QuestionDifficulty.medium,
    setterId: setterCS.id, setterName: setterCS.name,
    text: 'TCP provides which type of communication?',
    options: ['Connectionless', 'Connection-oriented', 'Broadcast', 'Multicast only'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'cs_012', subjectCode: 'CS', subjectName: 'Computer Science',
    topic: 'Networks', difficulty: QuestionDifficulty.hard,
    setterId: setterCS.id, setterName: setterCS.name,
    text: 'In RSA encryption with public key (e, n), the modulus n is the product of:',
    options: ['Two prime numbers', 'Two composite numbers', 'A prime and a composite', 'Three prime numbers'],
    correctAnswerIndex: 0,
  ),
  RawQuestion(
    id: 'cs_013', subjectCode: 'CS', subjectName: 'Computer Science',
    topic: 'Data Structures', difficulty: QuestionDifficulty.medium,
    setterId: setterCS.id, setterName: setterCS.name,
    text: 'A full binary tree with n leaf nodes has how many internal nodes?',
    options: ['n', 'n − 1', 'n + 1', '2n − 1'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'cs_014', subjectCode: 'CS', subjectName: 'Computer Science',
    topic: 'Algorithms', difficulty: QuestionDifficulty.easy,
    setterId: setterCS.id, setterName: setterCS.name,
    text: 'Which paradigm does dynamic programming belong to?',
    options: ['Greedy', 'Divide and Conquer', 'Memoization / Optimal Substructure', 'Backtracking'],
    correctAnswerIndex: 2,
  ),
  RawQuestion(
    id: 'cs_015', subjectCode: 'CS', subjectName: 'Computer Science',
    topic: 'Operating Systems', difficulty: QuestionDifficulty.medium,
    setterId: setterCS.id, setterName: setterCS.name,
    text: 'Virtual memory allows a process to use memory that is:',
    options: ['Only in RAM', 'Larger than physical RAM using disk space', 'Only on the GPU', 'Shared with other processes only'],
    correctAnswerIndex: 1,
  ),
];

// ── Physics questions (15) ────────────────────────────────────────────────────

final List<RawQuestion> physicsQuestions = [
  RawQuestion(
    id: 'phy_001', subjectCode: 'PHY', subjectName: 'Physics',
    topic: 'Mechanics', difficulty: QuestionDifficulty.easy,
    setterId: setterPhy.id, setterName: setterPhy.name,
    text: 'Newton\'s second law states that F = ma. If m = 5 kg and a = 4 m/s², the force is:',
    options: ['1.25 N', '9 N', '20 N', '20 kg·m/s'],
    correctAnswerIndex: 2,
  ),
  RawQuestion(
    id: 'phy_002', subjectCode: 'PHY', subjectName: 'Physics',
    topic: 'Mechanics', difficulty: QuestionDifficulty.medium,
    setterId: setterPhy.id, setterName: setterPhy.name,
    text: 'A ball is thrown vertically upward at 20 m/s. The maximum height reached is (g = 10 m/s²):',
    options: ['10 m', '15 m', '20 m', '40 m'],
    correctAnswerIndex: 2,
  ),
  RawQuestion(
    id: 'phy_003', subjectCode: 'PHY', subjectName: 'Physics',
    topic: 'Mechanics', difficulty: QuestionDifficulty.hard,
    setterId: setterPhy.id, setterName: setterPhy.name,
    text: 'The moment of inertia of a solid cylinder of mass M and radius R about its central axis is:',
    options: ['MR²', '(1/2)MR²', '(2/5)MR²', '(1/3)MR²'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'phy_004', subjectCode: 'PHY', subjectName: 'Physics',
    topic: 'Optics', difficulty: QuestionDifficulty.easy,
    setterId: setterPhy.id, setterName: setterPhy.name,
    text: 'The speed of light in a vacuum is approximately:',
    options: ['3 × 10⁶ m/s', '3 × 10⁸ m/s', '3 × 10¹⁰ m/s', '3 × 10⁴ m/s'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'phy_005', subjectCode: 'PHY', subjectName: 'Physics',
    topic: 'Optics', difficulty: QuestionDifficulty.medium,
    setterId: setterPhy.id, setterName: setterPhy.name,
    text: 'A concave mirror has a focal length of 20 cm. An object is placed 60 cm from the mirror. The image distance is:',
    options: ['30 cm', '40 cm', '−30 cm', '−40 cm'],
    correctAnswerIndex: 0,
  ),
  RawQuestion(
    id: 'phy_006', subjectCode: 'PHY', subjectName: 'Physics',
    topic: 'Optics', difficulty: QuestionDifficulty.hard,
    setterId: setterPhy.id, setterName: setterPhy.name,
    text: 'Young\'s double-slit experiment produces bright fringes when the path difference is:',
    options: ['nλ/2', 'nλ', '(2n+1)λ/2', 'λ/n'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'phy_007', subjectCode: 'PHY', subjectName: 'Physics',
    topic: 'Thermodynamics', difficulty: QuestionDifficulty.easy,
    setterId: setterPhy.id, setterName: setterPhy.name,
    text: 'The first law of thermodynamics is a statement of conservation of:',
    options: ['Momentum', 'Charge', 'Energy', 'Mass'],
    correctAnswerIndex: 2,
  ),
  RawQuestion(
    id: 'phy_008', subjectCode: 'PHY', subjectName: 'Physics',
    topic: 'Thermodynamics', difficulty: QuestionDifficulty.medium,
    setterId: setterPhy.id, setterName: setterPhy.name,
    text: 'The efficiency of a Carnot engine operating between temperatures 500 K and 300 K is:',
    options: ['30%', '40%', '60%', '70%'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'phy_009', subjectCode: 'PHY', subjectName: 'Physics',
    topic: 'Thermodynamics', difficulty: QuestionDifficulty.hard,
    setterId: setterPhy.id, setterName: setterPhy.name,
    text: 'The entropy of an isolated system at thermodynamic equilibrium is:',
    options: ['Zero', 'Negative', 'Minimum', 'Maximum'],
    correctAnswerIndex: 3,
  ),
  RawQuestion(
    id: 'phy_010', subjectCode: 'PHY', subjectName: 'Physics',
    topic: 'Electromagnetism', difficulty: QuestionDifficulty.easy,
    setterId: setterPhy.id, setterName: setterPhy.name,
    text: 'Coulomb\'s law gives the force between two charges. If the distance is doubled, the force:',
    options: ['Doubles', 'Halves', 'Becomes 4 times', 'Becomes 1/4 times'],
    correctAnswerIndex: 3,
  ),
  RawQuestion(
    id: 'phy_011', subjectCode: 'PHY', subjectName: 'Physics',
    topic: 'Electromagnetism', difficulty: QuestionDifficulty.medium,
    setterId: setterPhy.id, setterName: setterPhy.name,
    text: 'Faraday\'s law of electromagnetic induction states that the induced EMF is proportional to:',
    options: ['Magnetic field strength', 'Rate of change of magnetic flux', 'Current in the circuit', 'Resistance of the conductor'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'phy_012', subjectCode: 'PHY', subjectName: 'Physics',
    topic: 'Electromagnetism', difficulty: QuestionDifficulty.hard,
    setterId: setterPhy.id, setterName: setterPhy.name,
    text: 'Maxwell\'s displacement current was introduced to make which law consistent?',
    options: ['Gauss\'s Law', 'Faraday\'s Law', 'Ampere\'s Law', 'Biot-Savart Law'],
    correctAnswerIndex: 2,
  ),
  RawQuestion(
    id: 'phy_013', subjectCode: 'PHY', subjectName: 'Physics',
    topic: 'Mechanics', difficulty: QuestionDifficulty.medium,
    setterId: setterPhy.id, setterName: setterPhy.name,
    text: 'The work done by a force of 10 N over a displacement of 5 m at 60° to the force is:',
    options: ['25 J', '43.3 J', '50 J', '86.6 J'],
    correctAnswerIndex: 0,
  ),
  RawQuestion(
    id: 'phy_014', subjectCode: 'PHY', subjectName: 'Physics',
    topic: 'Optics', difficulty: QuestionDifficulty.medium,
    setterId: setterPhy.id, setterName: setterPhy.name,
    text: 'The critical angle for total internal reflection in glass (n = 1.5) is approximately:',
    options: ['30°', '42°', '45°', '60°'],
    correctAnswerIndex: 1,
  ),
  RawQuestion(
    id: 'phy_015', subjectCode: 'PHY', subjectName: 'Physics',
    topic: 'Thermodynamics', difficulty: QuestionDifficulty.easy,
    setterId: setterPhy.id, setterName: setterPhy.name,
    text: 'In an ideal gas, the internal energy depends on:',
    options: ['Pressure only', 'Volume only', 'Temperature only', 'Both pressure and volume'],
    correctAnswerIndex: 2,
  ),
];

/// All questions grouped by setter
final Map<String, List<RawQuestion>> allDummyQuestions = {
  setterMath.id: mathQuestions,
  setterCS.id: csQuestions,
  setterPhy.id: physicsQuestions,
};

/// All setter profiles list
final List<SetterProfile> allSetterProfiles = [setterMath, setterCS, setterPhy];
