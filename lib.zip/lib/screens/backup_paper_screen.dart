import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/paper_provider.dart';
import '../providers/question_provider.dart';
import '../providers/audit_provider.dart';
import '../models/audit_log.dart';
import '../models/exam_paper.dart';
import '../services/crypto_service.dart';
import '../theme/app_theme.dart';
import '../widgets/security_status_bar.dart';
import '../widgets/app_sidebar.dart';

class BackupPaperScreen extends StatefulWidget {
  const BackupPaperScreen({super.key});

  @override
  State<BackupPaperScreen> createState() => _BackupPaperScreenState();
}

class _BackupPaperScreenState extends State<BackupPaperScreen>
    with SingleTickerProviderStateMixin {
  late AnimationController _genController;
  late Animation<double> _genFade;

  @override
  void initState() {
    super.initState();
    _genController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _genFade = CurvedAnimation(parent: _genController, curve: Curves.easeOut);
  }

  @override
  void dispose() {
    _genController.dispose();
    super.dispose();
  }

  Future<void> _generateBackup(BuildContext context) async {
    final paper = context.read<PaperProvider>();
    final questions = context.read<QuestionProvider>();
    final audit = context.read<AuditProvider>();

    await paper.generateBackupPaper(questions.getAllRaw());

    _genController.forward(from: 0);

    audit.log(
      action: AuditActions.backupGenerated,
      actorId: 'admin',
      actorName: 'Admin Controller',
      actorRole: 'Admin',
      severity: AuditSeverity.success,
      metadata: {
        'backupId': paper.backupPaper?.id ?? '',
        'seed': paper.backupPaper?.seed.substring(0, 16).toUpperCase() ?? '',
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final paper = context.watch<PaperProvider>();

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Column(
        children: [
          const SecurityStatusBar(),
          Expanded(
            child: Row(
              children: [
                const AppSidebar(currentRoute: '/admin/backup'),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildHeader(context),
                        const SizedBox(height: 24),
                        if (!paper.hasPaper || !paper.primaryPaper!.status.isLocked)
                          _buildNoPrimaryState(context)
                        else
                          _buildContent(context, paper),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      children: [
        const Icon(Icons.copy_all_rounded, color: const Color(0xFF26C6DA)),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Backup Paper Generator',
                style: Theme.of(context).textTheme.headlineSmall),
            Text(
                'Emergency alternate paper with derived seed — same pool, different order',
                style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ],
    );
  }

  Widget _buildNoPrimaryState(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.only(top: 60),
        child: Column(
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: BoxDecoration(
                color: AppTheme.border,
                borderRadius: BorderRadius.circular(18),
              ),
              child: const Icon(Icons.block_rounded, color: AppTheme.textMuted, size: 34),
            ),
            const SizedBox(height: 20),
            Text('No Sealed Primary Paper',
                style: Theme.of(context).textTheme.headlineMedium),
            const SizedBox(height: 8),
            Text(
              'A primary paper must be generated and sealed before creating a backup.',
              style: Theme.of(context).textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildContent(BuildContext context, PaperProvider paper) {
    final primary = paper.primaryPaper!;
    const backupSalt = 'BACKUP_SALT_2026';
    final backupSeedPreview = paper.hasBackup
        ? paper.backupPaper!.seed
        : CryptoService.generateBackupSeed(paper.currentSeed, backupSalt);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Seed derivation comparison
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: _buildSeedCard(
              context,
              title: 'Primary Seed',
              seed: primary.seed,
              color: AppTheme.accent,
              label: 'ORIGINAL',
            )),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 40),
              child: Column(
                children: [
                  const Icon(Icons.arrow_forward_rounded, color: AppTheme.textMuted),
                  const SizedBox(height: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppTheme.panelLight,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      'SALT\nROTATE\n⊕',
                      style: AppTheme.monoStyle(
                        fontSize: 9,
                        color: AppTheme.textMuted,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ),
                  const SizedBox(height: 6),
                  const Icon(Icons.arrow_forward_rounded, color: AppTheme.textMuted),
                ],
              ),
            ),
            Expanded(child: _buildSeedCard(
              context,
              title: 'Backup Seed',
              seed: backupSeedPreview,
              color: const Color(0xFF26C6DA),
              label: 'BACKUP',
            )),
          ],
        ),
        const SizedBox(height: 20),
        // Backup derivation info
        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.panel,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'HOW BACKUP SEED IS DERIVED',
                style: AppTheme.monoStyle(
                  fontSize: 10,
                  color: const Color(0xFF26C6DA),
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(height: 10),
              Text(
                'backup_seed[i] = (primary_seed[(i+1) % 32] XOR SHA256(salt)[i]) & 0xFF',
                style: AppTheme.monoStyle(fontSize: 10, color: AppTheme.textSecondary),
              ),
              const SizedBox(height: 6),
              Text(
                'Salt: "$backupSalt" | This produces a completely different question ordering while using the same question pool.',
                style: AppTheme.monoStyle(fontSize: 9, color: AppTheme.textMuted),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),

        // Generate button
        if (!paper.hasBackup)
          ElevatedButton.icon(
            onPressed: paper.isGenerating ? null : () => _generateBackup(context),
            icon: paper.isGenerating
                ? const SizedBox(
                    width: 14,
                    height: 14,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: AppTheme.textInverse,
                    ),
                  )
                : const Icon(Icons.add_circle_outline_rounded),
            label: Text(
                paper.isGenerating ? 'Generating...' : 'Generate Backup Paper'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF26C6DA),
              foregroundColor: Colors.white,
              padding:
                  const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
            ),
          ),

        // Backup paper details
        if (paper.hasBackup) ...[
          const SizedBox(height: 20),
          FadeTransition(
            opacity: _genFade,
            child: _buildBackupPaperPanel(context, paper),
          ),
        ],
      ],
    );
  }

  Widget _buildSeedCard(
    BuildContext context, {
    required String title,
    required String seed,
    required Color color,
    required String label,
  }) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: AppTheme.panelGradient,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                title,
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(color: AppTheme.textPrimary),
              ),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: color.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  label,
                  style: AppTheme.monoStyle(
                    fontSize: 9,
                    color: color,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(
            CryptoService.formatHex(seed, groupSize: 8),
            style: AppTheme.monoStyle(
              fontSize: 9,
              color: color.withOpacity(0.9),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            '64-hex chars (256-bit)',
            style: AppTheme.monoStyle(fontSize: 8, color: AppTheme.textMuted),
          ),
        ],
      ),
    );
  }

  Widget _buildBackupPaperPanel(BuildContext context, PaperProvider paper) {
    final backup = paper.backupPaper!;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.panelGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
            color: const Color(0xFF26C6DA).withOpacity(0.4), width: 1.5),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.verified_rounded,
                  size: 16, color: Color(0xFF26C6DA)),
              const SizedBox(width: 8),
              Text(
                'Backup Paper Generated & Sealed',
                style: Theme.of(context)
                    .textTheme
                    .titleLarge
                    ?.copyWith(color: const Color(0xFF26C6DA)),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(color: AppTheme.border, height: 1),
          const SizedBox(height: 16),
          _metaRow(context, 'Backup ID', backup.id),
          _metaRow(context, 'Status', backup.status.label.toUpperCase()),
          _metaRow(context, 'Questions', '${backup.questions.length}'),
          _metaRow(context, 'Backup Salt', backup.backupSalt ?? 'N/A'),
          _metaRow(
              context,
              'Signature',
              '${backup.adminSignature.substring(0, 32).toUpperCase()}...'),
          const SizedBox(height: 16),
          // First 3 questions preview
          Text(
            'QUESTION ORDER PREVIEW (first 3)',
            style: AppTheme.monoStyle(
              fontSize: 10,
              color: AppTheme.textMuted,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 10),
          ...backup.questions.take(3).map(
                (q) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: AppTheme.background,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(color: AppTheme.border),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Q${q.questionNumber} [${q.topic}]',
                          style: AppTheme.monoStyle(
                            fontSize: 10,
                            color: const Color(0xFF26C6DA),
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          q.text,
                          style: Theme.of(context).textTheme.bodySmall,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
          if (backup.questions.length > 3)
            Text(
              '... and ${backup.questions.length - 3} more questions (different order from primary)',
              style: Theme.of(context).textTheme.bodySmall,
            ),
        ],
      ),
    );
  }

  Widget _metaRow(BuildContext context, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 100,
            child: Text(
              label,
              style: AppTheme.monoStyle(fontSize: 10, color: AppTheme.textMuted),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: AppTheme.monoStyle(
                  fontSize: 10, color: AppTheme.textPrimary),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
