import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../theme/app_theme.dart';

class LandingScreen extends StatefulWidget {
  const LandingScreen({super.key});

  @override
  State<LandingScreen> createState() => _LandingScreenState();
}

class _LandingScreenState extends State<LandingScreen>
    with TickerProviderStateMixin {
  late AnimationController _heroController;
  late AnimationController _cardsController;
  late Animation<double> _heroFade;
  late Animation<Offset> _heroSlide;
  late Animation<double> _cardsFade;

  @override
  void initState() {
    super.initState();
    _heroController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    );
    _cardsController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 700),
    );

    _heroFade = CurvedAnimation(parent: _heroController, curve: Curves.easeOut);
    _heroSlide = Tween<Offset>(begin: const Offset(0, 0.08), end: Offset.zero)
        .animate(CurvedAnimation(parent: _heroController, curve: Curves.easeOut));
    _cardsFade = CurvedAnimation(parent: _cardsController, curve: Curves.easeOut);

    _heroController.forward().then((_) {
      Future.delayed(const Duration(milliseconds: 200), () {
        if (mounted) _cardsController.forward();
      });
    });
  }

  @override
  void dispose() {
    _heroController.dispose();
    _cardsController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Stack(
        children: [
          // Animated grid background
          const _GridBackground(),
          // Main content
          SingleChildScrollView(
            child: Column(
              children: [
                _buildHero(context),
                _buildFeatureCards(context),
                _buildProcessTimeline(context),
                _buildCTASection(context),
                _buildFooter(context),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHero(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 80, horizontal: 40),
      child: FadeTransition(
        opacity: _heroFade,
        child: SlideTransition(
          position: _heroSlide,
          child: Column(
            children: [
              // Glowing lock icon
              Container(
                width: 80,
                height: 80,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  gradient: AppTheme.accentGradient,
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.accent.withOpacity(0.4),
                      blurRadius: 32,
                      spreadRadius: 4,
                    ),
                  ],
                ),
                child: const Icon(Icons.lock, color: Colors.white, size: 36),
              ),
              const SizedBox(height: 28),
              ShaderMask(
                shaderCallback: (bounds) =>
                    AppTheme.accentGradient.createShader(bounds),
                child: Text(
                  'SecureExam',
                  style: Theme.of(context).textTheme.displayLarge?.copyWith(
                        color: Colors.white,
                        letterSpacing: -1,
                      ),
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Safe Question Paper Generation & Transfer System',
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      color: AppTheme.textSecondary,
                      fontWeight: FontWeight.w400,
                    ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 8),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                decoration: BoxDecoration(
                  color: AppTheme.warning.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.warning.withOpacity(0.4)),
                ),
                child: Text(
                  '⚠️  SIMULATION / DEMONSTRATION ONLY',
                  style: AppTheme.monoStyle(
                    fontSize: 10,
                    color: AppTheme.warning,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(height: 40),
              // Stats row
              Wrap(
                spacing: 40,
                runSpacing: 16,
                alignment: WrapAlignment.center,
                children: [
                  _heroStat('3', 'Question Setters'),
                  _heroStat('45', 'Encrypted Questions'),
                  _heroStat('AES-256', 'Encryption'),
                  _heroStat('SHA-256', 'Signatures'),
                ],
              ),
              const SizedBox(height: 48),
              SizedBox(
                width: 220,
                height: 52,
                child: ElevatedButton.icon(
                  onPressed: () => context.go('/role-select'),
                  icon: const Icon(Icons.arrow_forward_rounded),
                  label: const Text('Enter System'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppTheme.accent,
                    foregroundColor: AppTheme.textInverse,
                    textStyle: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w700),
                    shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(14)),
                    elevation: 0,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _heroStat(String value, String label) {
    return Column(
      children: [
        Text(
          value,
          style: Theme.of(context).textTheme.headlineLarge?.copyWith(
                color: AppTheme.accent,
                fontWeight: FontWeight.w800,
              ),
        ),
        Text(label, style: Theme.of(context).textTheme.bodySmall),
      ],
    );
  }

  Widget _buildFeatureCards(BuildContext context) {
    final features = [
      (
        icon: Icons.key_rounded,
        color: AppTheme.accent,
        title: 'Hybrid Encryption',
        desc:
            'AES-256-GCM encrypts each question. AES keys are wrapped with the setter\'s RSA key material (simulated). Only the admin can decrypt.',
      ),
      (
        icon: Icons.shuffle_rounded,
        color: AppTheme.secure,
        title: 'Verifiable Randomization',
        desc:
            'Paper order is seeded by XOR of all setters\' SHA-256 key fingerprints. Anyone with public keys can independently verify the ordering.',
      ),
      (
        icon: Icons.verified_user_rounded,
        color: AppTheme.warning,
        title: 'Chain of Custody',
        desc:
            'Every action — submission, generation, sealing, dispatch, and printing — is logged with an immutable audit trail.',
      ),
      (
        icon: Icons.fingerprint,
        color: AppTheme.danger,
        title: 'Biometric Access Control',
        desc:
            'Fingerprint and Face ID gates protect every role. Admin and Print Officer require biometric verification before accessing sensitive operations.',
      ),
      (
        icon: Icons.document_scanner_rounded,
        color: Color(0xFFAB47BC),
        title: 'AI / OCR Fairness Check',
        desc:
            'Automated scan verifies question count, difficulty balance, topic coverage, and print layout integrity before dispatch.',
      ),
      (
        icon: Icons.copy_all_rounded,
        color: Color(0xFF26C6DA),
        title: 'Quick Backup Generation',
        desc:
            'Emergency alternate paper derived from a salted backup seed — same question pool, different ordering, instantly available.',
      ),
    ];

    return FadeTransition(
      opacity: _cardsFade,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
        child: Column(
          children: [
            Text(
              'Security Architecture',
              style: Theme.of(context)
                  .textTheme
                  .headlineMedium
                  ?.copyWith(color: AppTheme.textPrimary),
            ),
            const SizedBox(height: 8),
            Text(
              'How the system protects exam integrity at every stage',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: 32),
            LayoutBuilder(
              builder: (context, constraints) {
                final crossAxis =
                    constraints.maxWidth > 900 ? 3 : (constraints.maxWidth > 600 ? 2 : 1);
                return Wrap(
                  spacing: 16,
                  runSpacing: 16,
                  children: features
                      .map(
                        (f) => SizedBox(
                          width: (constraints.maxWidth - (crossAxis - 1) * 16) /
                              crossAxis,
                          child: _featureCard(
                            context,
                            icon: f.icon,
                            color: f.color,
                            title: f.title,
                            desc: f.desc,
                          ),
                        ),
                      )
                      .toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _featureCard(
    BuildContext context, {
    required IconData icon,
    required Color color,
    required String title,
    required String desc,
  }) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.panelGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color.withOpacity(0.2)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 44,
            height: 44,
            decoration: BoxDecoration(
              color: color.withOpacity(0.12),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 22),
          ),
          const SizedBox(height: 14),
          Text(title,
              style: Theme.of(context)
                  .textTheme
                  .titleLarge
                  ?.copyWith(color: AppTheme.textPrimary)),
          const SizedBox(height: 8),
          Text(desc, style: Theme.of(context).textTheme.bodySmall?.copyWith(height: 1.6)),
        ],
      ),
    );
  }

  Widget _buildProcessTimeline(BuildContext context) {
    final steps = [
      ('✍️', 'Question Setters', 'Submit questions encrypted with their RSA key material'),
      ('🔒', 'Encrypted Vault', 'Only AES-256-GCM ciphertexts stored — no plaintext'),
      ('⚙️', 'Paper Generation', 'Seed derived from all setters\' key XOR — verifiable shuffle'),
      ('🛡️', 'Seal & Sign', 'Admin signs paper with SHA-256 signature before dispatch'),
      ('📡', 'Secure Dispatch', 'Encrypted sealed packet transmitted to print center'),
      ('🖨️', 'Print Center', 'Officer unlocks with OTP + biometric — paper decrypts'),
    ];

    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 40),
      child: Column(
        children: [
          Text(
            'The Pipeline',
            style: Theme.of(context)
                .textTheme
                .headlineMedium
                ?.copyWith(color: AppTheme.textPrimary),
          ),
          const SizedBox(height: 32),
          LayoutBuilder(builder: (context, constraints) {
            final isWide = constraints.maxWidth > 700;
            if (isWide) {
              return Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: steps
                    .asMap()
                    .entries
                    .map((e) => Expanded(
                          child: _timelineStep(
                            context,
                            emoji: e.value.$1,
                            title: e.value.$2,
                            desc: e.value.$3,
                            index: e.key,
                            total: steps.length,
                            isWide: true,
                          ),
                        ))
                    .toList(),
              );
            } else {
              return Column(
                children: steps
                    .asMap()
                    .entries
                    .map((e) => _timelineStep(
                          context,
                          emoji: e.value.$1,
                          title: e.value.$2,
                          desc: e.value.$3,
                          index: e.key,
                          total: steps.length,
                          isWide: false,
                        ))
                    .toList(),
              );
            }
          }),
        ],
      ),
    );
  }

  Widget _timelineStep(
    BuildContext context, {
    required String emoji,
    required String title,
    required String desc,
    required int index,
    required int total,
    required bool isWide,
  }) {
    return Padding(
      padding: EdgeInsets.only(right: isWide ? 0 : 0, bottom: isWide ? 0 : 16),
      child: Column(
        children: [
          Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: AppTheme.accentGlow,
                  shape: BoxShape.circle,
                  border: Border.all(color: AppTheme.accent.withOpacity(0.5)),
                ),
                child: Center(
                  child: Text(emoji, style: const TextStyle(fontSize: 16)),
                ),
              ),
              if (isWide && index < total - 1)
                Expanded(
                  child: Container(height: 1, color: AppTheme.border),
                ),
            ],
          ),
          const SizedBox(height: 12),
          if (!isWide)
            Align(
              alignment: Alignment.centerLeft,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: Theme.of(context)
                          .textTheme
                          .titleMedium
                          ?.copyWith(color: AppTheme.textPrimary)),
                  const SizedBox(height: 4),
                  Text(desc,
                      style: Theme.of(context).textTheme.bodySmall),
                ],
              ),
            )
          else
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title,
                    style: Theme.of(context)
                        .textTheme
                        .labelLarge
                        ?.copyWith(color: AppTheme.textPrimary),
                    maxLines: 2),
                const SizedBox(height: 4),
                Text(desc,
                    style: Theme.of(context)
                        .textTheme
                        .bodySmall
                        ?.copyWith(fontSize: 11),
                    maxLines: 3),
              ],
            ),
        ],
      ),
    );
  }

  Widget _buildCTASection(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 40, vertical: 20),
      padding: const EdgeInsets.all(40),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFF0A2040), Color(0xFF0A1628)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppTheme.accent.withOpacity(0.3)),
      ),
      child: Column(
        children: [
          Text(
            'Ready to explore the simulation?',
            style: Theme.of(context)
                .textTheme
                .headlineMedium
                ?.copyWith(color: AppTheme.textPrimary),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          Text(
            'Select a role to enter the system. Start as a Question Setter to see encryption in action,\nthen switch to Admin for paper generation, and Print Officer for secure decryption.',
            style: Theme.of(context)
                .textTheme
                .bodyMedium
                ?.copyWith(height: 1.6),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 28),
          ElevatedButton.icon(
            onPressed: () => context.go('/role-select'),
            icon: const Icon(Icons.login_rounded),
            label: const Text('Select Your Role'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.accent,
              foregroundColor: AppTheme.textInverse,
              padding: const EdgeInsets.symmetric(horizontal: 32, vertical: 16),
              textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14)),
              elevation: 0,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFooter(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(32),
      child: Text(
        '⚠️  This is a demonstration project. No real exam data is used or processed.',
        style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: AppTheme.textMuted,
              fontStyle: FontStyle.italic,
            ),
        textAlign: TextAlign.center,
      ),
    );
  }
}

class _GridBackground extends StatelessWidget {
  const _GridBackground();

  @override
  Widget build(BuildContext context) {
    return CustomPaint(
      painter: _GridPainter(),
      size: Size(
        MediaQuery.of(context).size.width,
        MediaQuery.of(context).size.height,
      ),
    );
  }
}

class _GridPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppTheme.border.withOpacity(0.3)
      ..strokeWidth = 0.5;

    const spacing = 40.0;
    for (double x = 0; x < size.width; x += spacing) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }
    for (double y = 0; y < size.height; y += spacing) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }

    // Radial gradient overlay to fade edges
    final radialPaint = Paint()
      ..shader = RadialGradient(
        colors: [Colors.transparent, AppTheme.background.withOpacity(0.85)],
        radius: 0.7,
      ).createShader(Rect.fromLTWH(0, 0, size.width, size.height));
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), radialPaint);
  }

  @override
  bool shouldRepaint(_) => false;
}
