import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../models/user_role.dart';
import '../models/setter_profile.dart';
import '../providers/auth_provider.dart';
import '../providers/audit_provider.dart';
import '../models/audit_log.dart';
import '../services/biometric_service.dart';
import '../data/dummy_questions.dart';
import '../theme/app_theme.dart';

class BiometricGateScreen extends StatefulWidget {
  final String roleName;

  const BiometricGateScreen({super.key, required this.roleName});

  @override
  State<BiometricGateScreen> createState() => _BiometricGateScreenState();
}

class _BiometricGateScreenState extends State<BiometricGateScreen>
    with TickerProviderStateMixin {
  late AnimationController _scanController;
  late AnimationController _successController;
  late Animation<double> _scanAnim;
  late Animation<double> _successScale;

  double _progress = 0;
  bool _done = false;
  bool _started = false;
  SetterProfile? _selectedSetter;

  UserRole get _role =>
      UserRole.values.firstWhere((r) => r.name == widget.roleName);

  bool get _isSetter => _role == UserRole.setter;

  @override
  void initState() {
    super.initState();
    _scanController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );
    _successController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 500),
    );
    _scanAnim = CurvedAnimation(parent: _scanController, curve: Curves.linear);
    _successScale = CurvedAnimation(
      parent: _successController,
      curve: Curves.elasticOut,
    );

    if (!_isSetter) {
      // Auto-start biometric for non-setter roles
      Future.delayed(const Duration(milliseconds: 600), _startScan);
    }
  }

  @override
  void dispose() {
    _scanController.dispose();
    _successController.dispose();
    super.dispose();
  }

  Future<void> _startScan() async {
    if (_started) return;
    setState(() => _started = true);
    _scanController.repeat();

    await BiometricService.scanFingerprint(
      onProgress: (p) {
        if (mounted) setState(() => _progress = p);
      },
    );

    _scanController.stop();
    _successController.forward();
    if (mounted) setState(() => _done = true);

    await Future.delayed(const Duration(milliseconds: 800));
    if (!mounted) return;

    final auth = context.read<AuthProvider>();
    final audit = context.read<AuditProvider>();

    if (_isSetter && _selectedSetter != null) {
      auth.loginAsSetter(_selectedSetter!);
    } else {
      auth.completeBiometric();
    }

    audit.log(
      action: AuditActions.biometricVerified,
      actorId: auth.actorId,
      actorName: auth.actorName,
      actorRole: _role.shortName,
      severity: AuditSeverity.success,
      metadata: {'role': _role.displayName, 'type': 'FINGERPRINT'},
    );

    _navigateToRole(context);
  }

  void _navigateToRole(BuildContext context) {
    switch (_role) {
      case UserRole.setter:
        context.go('/setter');
      case UserRole.admin:
        context.go('/admin');
      case UserRole.printOfficer:
        context.go('/print');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 500),
          child: Padding(
            padding: const EdgeInsets.all(40),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Role title
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppTheme.accentGlow,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    _role.displayName.toUpperCase(),
                    style: AppTheme.monoStyle(
                      fontSize: 10,
                      color: AppTheme.accent,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                Text(
                  _done ? 'Access Granted' : 'Biometric Verification',
                  style: Theme.of(context).textTheme.headlineLarge,
                ),
                const SizedBox(height: 8),
                Text(
                  _done
                      ? 'Identity confirmed. Redirecting...'
                      : 'Place your finger on the scanner or look at the camera',
                  style: Theme.of(context).textTheme.bodyMedium,
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 48),

                // Setter profile selector (only for setter role before scan)
                if (_isSetter && !_started) ...[
                  _buildSetterSelector(),
                  const SizedBox(height: 32),
                ],

                // Fingerprint animation
                _buildFingerprintWidget(),

                const SizedBox(height: 32),

                // Progress bar
                if (_started && !_done) ...[
                  ClipRRect(
                    borderRadius: BorderRadius.circular(4),
                    child: LinearProgressIndicator(
                      value: _progress,
                      minHeight: 4,
                      backgroundColor: AppTheme.border,
                      valueColor: const AlwaysStoppedAnimation(AppTheme.accent),
                    ),
                  ),
                  const SizedBox(height: 12),
                  Text(
                    '${(_progress * 100).round()}% — Scanning biometric data...',
                    style: AppTheme.monoStyle(fontSize: 11, color: AppTheme.textMuted),
                  ),
                ],

                if (_done)
                  Text(
                    '✅  FINGERPRINT MATCHED — SESSION ACTIVE',
                    style: AppTheme.monoStyle(
                      fontSize: 11,
                      color: AppTheme.secure,
                      fontWeight: FontWeight.w700,
                    ),
                  ),

                // Start button (setter must pick profile first)
                if (_isSetter && !_started && _selectedSetter != null) ...[
                  const SizedBox(height: 24),
                  ElevatedButton.icon(
                    onPressed: _startScan,
                    icon: const Icon(Icons.fingerprint),
                    label: const Text('Authenticate'),
                    style: ElevatedButton.styleFrom(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 32, vertical: 14),
                    ),
                  ),
                ],

                const SizedBox(height: 40),
                TextButton(
                  onPressed: () => context.go('/role-select'),
                  child: const Text('← Back to role selection'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildSetterSelector() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'SELECT SETTER IDENTITY',
          style: AppTheme.monoStyle(
            fontSize: 10,
            color: AppTheme.accent,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 12),
        ...allSetterProfiles.map(
          (s) => GestureDetector(
            onTap: () => setState(() => _selectedSetter = s),
            child: AnimatedContainer(
              duration: const Duration(milliseconds: 150),
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: _selectedSetter?.id == s.id
                    ? AppTheme.accentGlow
                    : AppTheme.surface,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: _selectedSetter?.id == s.id
                      ? AppTheme.accent
                      : AppTheme.border,
                ),
              ),
              child: Row(
                children: [
                  Icon(
                    Icons.person_rounded,
                    size: 20,
                    color: _selectedSetter?.id == s.id
                        ? AppTheme.accent
                        : AppTheme.textMuted,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          s.name,
                          style: Theme.of(context).textTheme.titleMedium?.copyWith(
                                color: AppTheme.textPrimary,
                              ),
                        ),
                        Text(
                          s.subjectName,
                          style: Theme.of(context).textTheme.labelSmall,
                        ),
                      ],
                    ),
                  ),
                  if (_selectedSetter?.id == s.id)
                    const Icon(Icons.check_circle,
                        color: AppTheme.accent, size: 18),
                ],
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildFingerprintWidget() {
    if (_done) {
      return ScaleTransition(
        scale: _successScale,
        child: Container(
          width: 100,
          height: 100,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: AppTheme.secureGlow,
            border: Border.all(color: AppTheme.secure, width: 2),
            boxShadow: [
              BoxShadow(
                  color: AppTheme.secure.withOpacity(0.4), blurRadius: 24),
            ],
          ),
          child: const Icon(Icons.check_rounded,
              color: AppTheme.secure, size: 48),
        ),
      );
    }

    return AnimatedBuilder(
      animation: _scanAnim,
      builder: (_, __) {
        return CustomPaint(
          size: const Size(120, 120),
          painter: _FingerprintPainter(
            progress: _progress,
            scanning: _started,
            scanProgress: _scanAnim.value,
          ),
        );
      },
    );
  }
}

class _FingerprintPainter extends CustomPainter {
  final double progress;
  final bool scanning;
  final double scanProgress;

  const _FingerprintPainter({
    required this.progress,
    required this.scanning,
    required this.scanProgress,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final center = Offset(size.width / 2, size.height / 2);
    final maxRadius = size.width / 2 - 4;

    final bgPaint = Paint()
      ..color = AppTheme.surface
      ..style = PaintingStyle.fill;
    canvas.drawCircle(center, maxRadius + 4, bgPaint);

    final borderPaint = Paint()
      ..color = scanning ? AppTheme.accent : AppTheme.border
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2;
    canvas.drawCircle(center, maxRadius + 4, borderPaint);

    // Draw fingerprint ridges (concentric arcs)
    final ridgeCount = 6;
    for (var i = ridgeCount; i >= 1; i--) {
      final r = (maxRadius / ridgeCount) * i;
      final filled = progress >= i / ridgeCount;
      final ridgePaint = Paint()
        ..color = filled
            ? AppTheme.accent.withOpacity(0.6 + i * 0.06)
            : AppTheme.border.withOpacity(0.4)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.8;

      canvas.drawArc(
        Rect.fromCircle(center: center, radius: r),
        -0.8 + i * 0.05,
        3.1415 + i * 0.1,
        false,
        ridgePaint,
      );
    }

    // Scanning line
    if (scanning && !filled) {
      final scanY = center.dy - maxRadius + scanProgress * maxRadius * 2;
      final scanPaint = Paint()
        ..color = AppTheme.accent.withOpacity(0.6)
        ..strokeWidth = 1.5;
      canvas.drawLine(
        Offset(center.dx - maxRadius, scanY),
        Offset(center.dx + maxRadius, scanY),
        scanPaint,
      );
    }

    // Center icon
    final iconPaint = Paint()
      ..color = scanning ? AppTheme.accent : AppTheme.textMuted
      ..style = PaintingStyle.fill;
    canvas.drawCircle(center, 4, iconPaint);
  }

  bool get filled => progress >= 1.0;

  @override
  bool shouldRepaint(_FingerprintPainter old) =>
      old.progress != progress ||
      old.scanning != scanning ||
      old.scanProgress != scanProgress;
}
