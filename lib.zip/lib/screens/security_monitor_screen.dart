import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/paper_provider.dart';
import '../providers/audit_provider.dart';
import '../models/audit_log.dart';
import '../models/question.dart';
import '../theme/app_theme.dart';
import '../widgets/security_status_bar.dart';
import '../widgets/app_sidebar.dart';
import '../widgets/audit_log_tile.dart';
import '../services/ocr_simulator.dart';

class SecurityMonitorScreen extends StatefulWidget {
  const SecurityMonitorScreen({super.key});

  @override
  State<SecurityMonitorScreen> createState() => _SecurityMonitorScreenState();
}

class _SecurityMonitorScreenState extends State<SecurityMonitorScreen>
    with TickerProviderStateMixin {
  late AnimationController _scanController;
  late AnimationController _fadeController;
  late Animation<double> _scanAnim;
  late Animation<double> _fadeCertAnim;

  bool _isScanning = false;

  @override
  void initState() {
    super.initState();
    _scanController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    );
    _fadeController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _scanAnim = CurvedAnimation(parent: _scanController, curve: Curves.linear);
    _fadeCertAnim = CurvedAnimation(parent: _fadeController, curve: Curves.easeOut);
  }

  @override
  void dispose() {
    _scanController.dispose();
    _fadeController.dispose();
    super.dispose();
  }

  Future<void> _runOcrScan(BuildContext context) async {
    final paper = context.read<PaperProvider>();
    final audit = context.read<AuditProvider>();

    if (!paper.hasPaper) return;

    setState(() => _isScanning = true);
    _scanController.repeat();

    audit.log(
      action: AuditActions.ocrScanStarted,
      actorId: 'admin',
      actorName: 'Admin System',
      actorRole: 'Admin',
      severity: AuditSeverity.info,
    );

    await paper.runOcrCheck();

    _scanController.stop();
    _fadeController.forward(from: 0);
    setState(() => _isScanning = false);

    audit.log(
      action: AuditActions.ocrScanComplete,
      actorId: 'admin',
      actorName: 'Admin System',
      actorRole: 'Admin',
      severity: AuditSeverity.success,
      metadata: {
        'score': '${paper.fairnessReport?.overallScore.toStringAsFixed(1)}%',
        'cert': paper.fairnessReport?.certificateId ?? '',
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final paper = context.watch<PaperProvider>();
    final audit = context.watch<AuditProvider>();

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Column(
        children: [
          const SecurityStatusBar(),
          Expanded(
            child: Row(
              children: [
                const AppSidebar(currentRoute: '/admin/security'),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildHeader(context),
                        const SizedBox(height: 24),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(flex: 3, child: _buildOcrPanel(context, paper)),
                            const SizedBox(width: 20),
                            Expanded(flex: 2, child: _buildThreatBoard(context)),
                          ],
                        ),
                        const SizedBox(height: 20),
                        if (paper.hasPaper)
                          _buildChainOfCustody(context, paper),
                        const SizedBox(height: 20),
                        _buildAuditTimeline(context, audit),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      children: [
        const Icon(Icons.monitor_heart_rounded, color: AppTheme.secure),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Security Monitor',
                style: Theme.of(context).textTheme.headlineSmall),
            Text('OCR fairness check, audit log, chain of custody',
                style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ],
    );
  }

  Widget _buildOcrPanel(BuildContext context, PaperProvider paper) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.panelGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.document_scanner_rounded,
                  size: 16, color: AppTheme.accent),
              const SizedBox(width: 8),
              Text('AI / OCR Fairness Analysis',
                  style: Theme.of(context).textTheme.titleLarge),
              const Spacer(),
              ElevatedButton.icon(
                onPressed: (paper.hasPaper && !_isScanning && !paper.isRunningOcr)
                    ? () => _runOcrScan(context)
                    : null,
                icon: _isScanning || paper.isRunningOcr
                    ? const SizedBox(
                        width: 14,
                        height: 14,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppTheme.textInverse,
                        ),
                      )
                    : const Icon(Icons.scanner_rounded),
                label: Text(_isScanning || paper.isRunningOcr
                    ? 'Scanning...'
                    : 'Run OCR Scan'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(color: AppTheme.border, height: 1),
          const SizedBox(height: 16),

          if (!paper.hasPaper)
            _emptyPanel(context, 'No paper generated yet',
                'Generate a paper first to run the OCR fairness check')
          else if (paper.fairnessReport == null && !_isScanning)
            _emptyPanel(context, 'Ready to scan',
                'Click "Run OCR Scan" to simulate AI fairness analysis')
          else if (_isScanning || paper.isRunningOcr)
            _buildScanAnimation(context)
          else if (paper.fairnessReport != null)
            _buildFairnessReport(context, paper.fairnessReport!),
        ],
      ),
    );
  }

  Widget _buildScanAnimation(BuildContext context) {
    return AnimatedBuilder(
      animation: _scanAnim,
      builder: (_, __) {
        return Column(
          children: [
            const SizedBox(height: 20),
            Stack(
              alignment: Alignment.center,
              children: [
                Container(
                  width: 200,
                  height: 260,
                  decoration: BoxDecoration(
                    color: AppTheme.background,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: AppTheme.border),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(
                      8,
                      (i) => Padding(
                        padding: const EdgeInsets.symmetric(
                            vertical: 4, horizontal: 16),
                        child: Container(
                          height: 8,
                          decoration: BoxDecoration(
                            color: AppTheme.border,
                            borderRadius: BorderRadius.circular(4),
                          ),
                        ),
                      ),
                    ),
                  ),
                ),
                // Scan line
                Positioned(
                  top: _scanAnim.value * 260,
                  left: 0,
                  right: 0,
                  child: Container(
                    height: 3,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [
                          Colors.transparent,
                          AppTheme.accent.withOpacity(0.8),
                          Colors.transparent,
                        ],
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: AppTheme.accent.withOpacity(0.4),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Text(
              'Scanning paper content...',
              style: AppTheme.monoStyle(
                fontSize: 11,
                color: AppTheme.accent,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Running AI fairness analysis, OCR verification, and layout checks',
              style: Theme.of(context).textTheme.bodySmall,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
          ],
        );
      },
    );
  }

  Widget _buildFairnessReport(BuildContext context, FairnessReport report) {
    return FadeTransition(
      opacity: _fadeCertAnim,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Score row
          Row(
            children: [
              _scoreCircle(
                'Overall',
                report.overallScore,
                AppTheme.secure,
              ),
              const SizedBox(width: 20),
              _scoreCircle(
                'Print Quality',
                report.printQualityScore.toDouble(),
                AppTheme.accent,
              ),
              const SizedBox(width: 20),
              _scoreCircle(
                'Content Integrity',
                report.contentIntegrityScore.toDouble(),
                AppTheme.warning,
              ),
              const SizedBox(width: 20),
              _scoreCircle(
                'Format Compliance',
                report.formatComplianceScore.toDouble(),
                const Color(0xFFAB47BC),
              ),
            ],
          ),
          const SizedBox(height: 20),
          // Difficulty chart
          _buildDifficultyChart(context, report),
          const SizedBox(height: 16),
          // Findings
          Text(
            'SCAN FINDINGS',
            style: AppTheme.monoStyle(
              fontSize: 10,
              color: AppTheme.secure,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          ...report.scanFindings.map(
            (f) => Padding(
              padding: const EdgeInsets.only(bottom: 6),
              child: Text(
                f,
                style: AppTheme.monoStyle(fontSize: 10, color: AppTheme.textSecondary),
              ),
            ),
          ),
          const SizedBox(height: 16),
          // Certificate
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppTheme.secure.withOpacity(0.06),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: AppTheme.secure.withOpacity(0.4)),
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    color: AppTheme.secure.withOpacity(0.15),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.verified_rounded,
                      color: AppTheme.secure, size: 20),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'FAIRNESS CERTIFICATE ISSUED',
                        style: AppTheme.monoStyle(
                          fontSize: 10,
                          color: AppTheme.secure,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Text(
                        'ID: ${report.certificateId}',
                        style: AppTheme.monoStyle(
                          fontSize: 10,
                          color: AppTheme.textSecondary,
                        ),
                      ),
                      Text(
                        'Issued: ${_formatDt(report.issuedAt)}',
                        style: AppTheme.monoStyle(
                          fontSize: 9,
                          color: AppTheme.textMuted,
                        ),
                      ),
                    ],
                  ),
                ),
                Text(
                  report.passed ? 'PASSED ✅' : 'FAILED ❌',
                  style: AppTheme.monoStyle(
                    fontSize: 12,
                    color: report.passed ? AppTheme.secure : AppTheme.danger,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _scoreCircle(String label, double score, Color color) {
    return Expanded(
      child: Column(
        children: [
          SizedBox(
            width: 70,
            height: 70,
            child: Stack(
              alignment: Alignment.center,
              children: [
                SizedBox(
                  width: 70,
                  height: 70,
                  child: CircularProgressIndicator(
                    value: score / 100,
                    backgroundColor: AppTheme.border,
                    valueColor: AlwaysStoppedAnimation(color),
                    strokeWidth: 6,
                  ),
                ),
                Text(
                  '${score.round()}',
                  style: AppTheme.monoStyle(
                    fontSize: 16,
                    color: color,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 6),
          Text(
            label,
            style: AppTheme.monoStyle(fontSize: 9, color: AppTheme.textMuted),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildDifficultyChart(BuildContext context, FairnessReport report) {
    final diffs = report.difficultyBreakdown;
    final easy = (diffs[QuestionDifficulty.easy] ?? 0).toDouble();
    final med = (diffs[QuestionDifficulty.medium] ?? 0).toDouble();
    final hard = (diffs[QuestionDifficulty.hard] ?? 0).toDouble();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'DIFFICULTY DISTRIBUTION',
          style: AppTheme.monoStyle(
            fontSize: 10,
            color: AppTheme.textMuted,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 100,
          child: BarChart(
            BarChartData(
              barGroups: [
                _barGroup(0, easy, AppTheme.secure),
                _barGroup(1, med, AppTheme.warning),
                _barGroup(2, hard, AppTheme.danger),
              ],
              titlesData: FlTitlesData(
                bottomTitles: AxisTitles(
                  sideTitles: SideTitles(
                    showTitles: true,
                    getTitlesWidget: (v, _) {
                      final labels = ['Easy', 'Medium', 'Hard'];
                      return Text(
                        labels[v.toInt()],
                        style: AppTheme.monoStyle(
                          fontSize: 8,
                          color: AppTheme.textMuted,
                        ),
                      );
                    },
                  ),
                ),
                leftTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
                topTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
                rightTitles: const AxisTitles(
                  sideTitles: SideTitles(showTitles: false),
                ),
              ),
              borderData: FlBorderData(show: false),
              gridData: const FlGridData(show: false),
            ),
          ),
        ),
      ],
    );
  }

  BarChartGroupData _barGroup(int x, double y, Color color) {
    return BarChartGroupData(
      x: x,
      barRods: [
        BarChartRodData(
          toY: y,
          color: color,
          width: 24,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
        ),
      ],
    );
  }

  Widget _buildThreatBoard(BuildContext context) {
    final threats = [
      ('Network Interception', AppTheme.secure, '0 detected'),
      ('Unauthorized Access', AppTheme.secure, '0 attempts'),
      ('Question Leaks', AppTheme.secure, '0 incidents'),
      ('Biometric Failures', AppTheme.secure, '0 failures'),
      ('Signature Tampering', AppTheme.secure, '0 detected'),
    ];

    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.panelGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.shield_rounded, size: 16, color: AppTheme.secure),
              const SizedBox(width: 8),
              Text('Threat Board', style: Theme.of(context).textTheme.titleLarge),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppTheme.secure.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(color: AppTheme.secure.withOpacity(0.4)),
                ),
                child: Text(
                  'ALL CLEAR',
                  style: AppTheme.monoStyle(
                    fontSize: 9,
                    color: AppTheme.secure,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(color: AppTheme.border, height: 1),
          const SizedBox(height: 16),
          ...threats.map(
            (t) => Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Row(
                children: [
                  Container(
                    width: 8,
                    height: 8,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: t.$2,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Text(
                      t.$1,
                      style: Theme.of(context)
                          .textTheme
                          .labelMedium
                          ?.copyWith(color: AppTheme.textPrimary),
                    ),
                  ),
                  Text(
                    t.$3,
                    style: AppTheme.monoStyle(
                      fontSize: 10,
                      color: t.$2,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
          ),
          const Divider(color: AppTheme.border),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppTheme.secure.withOpacity(0.06),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Row(
              children: [
                const Icon(Icons.lock_rounded,
                    size: 14, color: AppTheme.secure),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'End-to-end encryption active\nAll channels verified secure',
                    style: AppTheme.monoStyle(
                      fontSize: 9,
                      color: AppTheme.secure,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildChainOfCustody(BuildContext context, PaperProvider paper) {
    final custody = paper.primaryPaper!.chainOfCustody;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.panelGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.link_rounded, size: 16, color: AppTheme.accent),
              const SizedBox(width: 8),
              Text('Chain of Custody',
                  style: Theme.of(context).textTheme.titleLarge),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(color: AppTheme.border, height: 1),
          const SizedBox(height: 16),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: DataTable(
              headingRowColor: WidgetStatePropertyAll(AppTheme.background),
              headingTextStyle: AppTheme.monoStyle(
                fontSize: 10,
                color: AppTheme.accent,
                fontWeight: FontWeight.w700,
              ),
              dataTextStyle: AppTheme.monoStyle(
                fontSize: 10,
                color: AppTheme.textSecondary,
              ),
              columns: const [
                DataColumn(label: Text('ACTION')),
                DataColumn(label: Text('ACTOR')),
                DataColumn(label: Text('ROLE')),
                DataColumn(label: Text('TIMESTAMP')),
                DataColumn(label: Text('DETAILS')),
              ],
              rows: custody.map((c) => DataRow(cells: [
                    DataCell(Text(c.action.toUpperCase())),
                    DataCell(Text(c.actorName)),
                    DataCell(Text(c.actorRole.toUpperCase())),
                    DataCell(Text(_formatDt(c.timestamp))),
                    DataCell(ConstrainedBox(
                      constraints: const BoxConstraints(maxWidth: 300),
                      child: Text(c.details, overflow: TextOverflow.ellipsis),
                    )),
                  ])).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAuditTimeline(BuildContext context, AuditProvider audit) {
    final logs = audit.logs.take(15).toList();
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.panelGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.timeline_rounded, size: 16, color: AppTheme.accent),
              const SizedBox(width: 8),
              Text('Audit Timeline',
                  style: Theme.of(context).textTheme.titleLarge),
              const SizedBox(width: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                decoration: BoxDecoration(
                  color: AppTheme.accentGlow,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '${audit.logs.length} events',
                  style: AppTheme.monoStyle(
                    fontSize: 9,
                    color: AppTheme.accent,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(color: AppTheme.border, height: 1),
          const SizedBox(height: 16),
          if (logs.isEmpty)
            _emptyPanel(context, 'No events logged', 'System events will appear here'),
          ...logs.asMap().entries.map(
                (e) => AuditLogTile(log: e.value, isFirst: e.key == 0),
              ),
        ],
      ),
    );
  }

  Widget _emptyPanel(BuildContext context, String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 32),
      child: Center(
        child: Column(
          children: [
            const Icon(Icons.inbox_rounded, color: AppTheme.textMuted, size: 36),
            const SizedBox(height: 12),
            Text(title, style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Text(subtitle,
                style: Theme.of(context).textTheme.bodySmall,
                textAlign: TextAlign.center),
          ],
        ),
      ),
    );
  }

  String _formatDt(DateTime dt) {
    final d = '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}';
    final t = '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}:${dt.second.toString().padLeft(2, '0')}';
    return '$d $t';
  }
}
