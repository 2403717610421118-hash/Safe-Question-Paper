import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../models/exam_paper.dart';
import '../providers/question_provider.dart';
import '../providers/paper_provider.dart';
import '../providers/audit_provider.dart';
import '../models/audit_log.dart';
import '../data/dummy_questions.dart';
import '../services/crypto_service.dart';
import '../theme/app_theme.dart';
import '../widgets/security_status_bar.dart';
import '../widgets/app_sidebar.dart';

class PaperGenerationScreen extends StatefulWidget {
  const PaperGenerationScreen({super.key});

  @override
  State<PaperGenerationScreen> createState() => _PaperGenerationScreenState();
}

class _PaperGenerationScreenState extends State<PaperGenerationScreen>
    with TickerProviderStateMixin {
  late AnimationController _shuffleController;
  late AnimationController _seedController;
  late AnimationController _pulseController;
  late Animation<double> _shuffleAnim;
  late Animation<double> _seedFade;
  late Animation<double> _pulseAnim;

  @override
  void initState() {
    super.initState();
    _shuffleController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1200),
    );
    _seedController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);

    _shuffleAnim = CurvedAnimation(
      parent: _shuffleController,
      curve: Curves.easeInOut,
    );
    _seedFade = CurvedAnimation(parent: _seedController, curve: Curves.easeOut);
    _pulseAnim = CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut);
  }

  @override
  void dispose() {
    _shuffleController.dispose();
    _seedController.dispose();
    _pulseController.dispose();
    super.dispose();
  }

  Future<void> _generate(BuildContext context) async {
    final paper = context.read<PaperProvider>();
    final questions = context.read<QuestionProvider>();
    final audit = context.read<AuditProvider>();

    // Trigger shuffle animation during generation
    _shuffleController.repeat();
    _seedController.forward();

    audit.log(
      action: AuditActions.paperGenerationStarted,
      actorId: 'admin',
      actorName: 'Admin Controller',
      actorRole: 'Admin',
      severity: AuditSeverity.info,
    );

    await paper.generatePaper(questions.getAllRaw());

    _shuffleController.stop();
    _shuffleController.reset();

    audit.log(
      action: AuditActions.paperGenerated,
      actorId: 'admin',
      actorName: 'Admin Controller',
      actorRole: 'Admin',
      severity: AuditSeverity.success,
      metadata: {
        'paperId': paper.primaryPaper?.id ?? '',
        'seed': paper.currentSeed.substring(0, 16).toUpperCase(),
        'questions': '${paper.primaryPaper?.questions.length}',
      },
    );
  }

  Future<void> _seal(BuildContext context) async {
    final paper = context.read<PaperProvider>();
    final audit = context.read<AuditProvider>();
    await paper.sealPaper();

    audit.log(
      action: AuditActions.paperSealed,
      actorId: 'admin',
      actorName: 'Admin Controller',
      actorRole: 'Admin',
      severity: AuditSeverity.success,
      metadata: {'signature': paper.primaryPaper?.adminSignature.substring(0, 16).toUpperCase() ?? ''},
    );
  }

  Future<void> _dispatch(BuildContext context) async {
    final paper = context.read<PaperProvider>();
    final audit = context.read<AuditProvider>();
    await paper.dispatchPaper();

    audit.log(
      action: AuditActions.paperDispatched,
      actorId: 'admin',
      actorName: 'Admin Controller',
      actorRole: 'Admin',
      severity: AuditSeverity.success,
    );

    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('📡 Paper dispatched to Print Center'),
          backgroundColor: AppTheme.secure,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final paper = context.watch<PaperProvider>();
    final questions = context.watch<QuestionProvider>();

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Column(
        children: [
          const SecurityStatusBar(),
          Expanded(
            child: Row(
              children: [
                const AppSidebar(currentRoute: '/admin/generate'),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildHeader(context),
                        const SizedBox(height: 28),
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(flex: 2, child: _buildSeedPanel(context, paper)),
                            const SizedBox(width: 20),
                            Expanded(flex: 3, child: _buildGenerationPanel(context, paper, questions)),
                          ],
                        ),
                        const SizedBox(height: 20),
                        if (paper.hasPaper) _buildPaperPreview(context, paper),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      children: [
        const Icon(Icons.shuffle_rounded, color: AppTheme.accent),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Paper Generation Studio',
                style: Theme.of(context).textTheme.headlineSmall),
            Text('Verifiable randomization using setter key XOR seed',
                style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ],
    );
  }

  Widget _buildSeedPanel(BuildContext context, PaperProvider paper) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.panelGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.vpn_key_rounded, size: 16, color: AppTheme.accent),
              const SizedBox(width: 8),
              Text('Seed Derivation',
                  style: Theme.of(context).textTheme.titleLarge),
            ],
          ),
          const SizedBox(height: 6),
          Text('XOR of SHA-256(setter public keys)',
              style: Theme.of(context).textTheme.labelSmall),
          const SizedBox(height: 16),
          const Divider(color: AppTheme.border, height: 1),
          const SizedBox(height: 16),
          // Setter contributions
          ...allSetterProfiles.asMap().entries.map((e) {
            final s = e.value;
            final i = e.key;
            final component = paper.seedComponents.isNotEmpty && i < paper.seedComponents.length
                ? paper.seedComponents[i]
                : '????????????????';
            return Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: _seedContributionRow(context, s.name, component, i),
            );
          }),
          // XOR indicator
          if (paper.seedComponents.isNotEmpty) ...[
            Center(
              child: Column(
                children: [
                  const Icon(Icons.expand_more, color: AppTheme.textMuted),
                  Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 12, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppTheme.accentGlow,
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      'XOR ⊕',
                      style: AppTheme.monoStyle(
                        fontSize: 12,
                        color: AppTheme.accent,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                  const Icon(Icons.expand_more, color: AppTheme.textMuted),
                ],
              ),
            ),
            const SizedBox(height: 12),
          ],
          // Final seed
          Text(
            'PAPER SEED',
            style: AppTheme.monoStyle(
              fontSize: 9,
              color: AppTheme.warning,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          FadeTransition(
            opacity: _seedFade,
            child: Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.background,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: paper.currentSeed.isNotEmpty
                      ? AppTheme.warning.withOpacity(0.4)
                      : AppTheme.border,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    paper.currentSeed.isEmpty
                        ? '????????????????????????????????\n????????????????????????????????'
                        : CryptoService.formatHex(paper.currentSeed, groupSize: 8),
                    style: AppTheme.monoStyle(
                      fontSize: 10,
                      color: paper.currentSeed.isEmpty
                          ? AppTheme.textMuted
                          : AppTheme.warning,
                    ),
                  ),
                  if (paper.currentSeed.isNotEmpty) ...[
                    const SizedBox(height: 6),
                    Text(
                      '64-char hex (256-bit)',
                      style: AppTheme.monoStyle(
                        fontSize: 8,
                        color: AppTheme.textMuted,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          // How it works explainer
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppTheme.background,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppTheme.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'VERIFIABILITY',
                  style: AppTheme.monoStyle(
                    fontSize: 9,
                    color: AppTheme.secure,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  'Anyone with the 3 setters\' public keys can independently recompute this seed and verify the question ordering post-exam.',
                  style: AppTheme.monoStyle(
                    fontSize: 9,
                    color: AppTheme.textSecondary,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _seedContributionRow(
      BuildContext context, String name, String hashPreview, int index) {
    final colors = [AppTheme.accent, AppTheme.secure, AppTheme.warning];
    final color = colors[index % colors.length];

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppTheme.background,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: color.withOpacity(0.25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: color,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                name,
                style: AppTheme.monoStyle(
                  fontSize: 10,
                  color: AppTheme.textPrimary,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            'SHA256: $hashPreview...',
            style: AppTheme.monoStyle(fontSize: 9, color: color),
          ),
        ],
      ),
    );
  }

  Widget _buildGenerationPanel(
      BuildContext context, PaperProvider paper, QuestionProvider questions) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.panelGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.receipt_long_rounded,
                  size: 16, color: AppTheme.accent),
              const SizedBox(width: 8),
              Text('Paper Assembly', style: Theme.of(context).textTheme.titleLarge),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            '${PaperProvider.kQuestionsPerPaper} questions selected from ${questions.totalCount} encrypted pool',
            style: Theme.of(context).textTheme.labelSmall,
          ),
          const SizedBox(height: 16),
          const Divider(color: AppTheme.border, height: 1),
          const SizedBox(height: 16),

          // Step progress
          _buildSteps(context, paper),
          const SizedBox(height: 20),

          // Card shuffle animation
          if (paper.isGenerating || paper.hasPaper)
            _buildShuffleAnimation(paper),

          const SizedBox(height: 20),

          // Action buttons
          _buildActionButtons(context, paper, questions),

          // Signature display
          if (paper.hasPaper) ...[
            const SizedBox(height: 16),
            _buildSignaturePanel(context, paper),
          ],
        ],
      ),
    );
  }

  Widget _buildSteps(BuildContext context, PaperProvider paper) {
    final steps = [
      (GenerationStep.collectingKeys, 'Collecting Keys', Icons.key_rounded),
      (GenerationStep.computingSeed, 'Computing Seed', Icons.functions_rounded),
      (GenerationStep.shuffling, 'Shuffling Cards', Icons.shuffle_rounded),
      (GenerationStep.assembling, 'Assembling Paper', Icons.layers_rounded),
      (GenerationStep.signing, 'Signing Paper', Icons.verified_rounded),
      (GenerationStep.done, 'Done', Icons.check_circle_rounded),
    ];

    return Row(
      children: steps.asMap().entries.map((e) {
        final label = e.value.$2;
        final icon = e.value.$3;
        final currentIdx = steps.indexWhere((s) => s.$1 == paper.step);
        final thisIdx = e.key;
        final isDone = thisIdx < currentIdx || paper.step == GenerationStep.done;
        final isActive = thisIdx == currentIdx;

        return Expanded(
          child: Row(
            children: [
              Expanded(
                child: Column(
                  children: [
                    Container(
                      width: 32,
                      height: 32,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        color: isDone
                            ? AppTheme.secure
                            : isActive
                                ? AppTheme.accent
                                : AppTheme.surface,
                        border: Border.all(
                          color: isDone
                              ? AppTheme.secure
                              : isActive
                                  ? AppTheme.accent
                                  : AppTheme.border,
                        ),
                      ),
                      child: Icon(
                        isDone ? Icons.check_rounded : icon,
                        size: 14,
                        color: isDone || isActive
                            ? Colors.white
                            : AppTheme.textMuted,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      label,
                      style: AppTheme.monoStyle(
                        fontSize: 8,
                        color: isDone
                            ? AppTheme.secure
                            : isActive
                                ? AppTheme.accent
                                : AppTheme.textMuted,
                      ),
                      textAlign: TextAlign.center,
                    ),
                  ],
                ),
              ),
              if (e.key < steps.length - 1)
                Expanded(
                  child: Container(
                    height: 1,
                    margin: const EdgeInsets.only(bottom: 22),
                    color: e.key < currentIdx ? AppTheme.secure : AppTheme.border,
                  ),
                ),
            ],
          ),
        );
      }).toList(),
    );
  }

  Widget _buildShuffleAnimation(PaperProvider paper) {
    return AnimatedBuilder(
      animation: _pulseAnim,
      builder: (_, __) {
        return SizedBox(
          height: 80,
          child: Stack(
            children: List.generate(
              8,
              (i) {
                final progress = paper.generationProgress;
                // Cards fly around during shuffle, settle into place when done
                final settled = progress >= 0.8;
                final angle = settled
                    ? 0.0
                    : (i - 3.5) * 0.06 + _pulseAnim.value * 0.04;
                final offset = settled
                    ? Offset(i * 12.0, 0)
                    : Offset(
                        i * 12.0 + (i % 2 == 0 ? 1 : -1) * _pulseAnim.value * 8,
                        (i % 3 - 1) * 6.0 * (1 - progress),
                      );
                return Transform.translate(
                  offset: offset,
                  child: Transform.rotate(
                    angle: angle,
                    child: _miniCard(i, progress),
                  ),
                );
              },
            ),
          ),
        );
      },
    );
  }

  Widget _miniCard(int index, double progress) {
    final colors = [
      AppTheme.accent,
      AppTheme.secure,
      AppTheme.warning,
      const Color(0xFFAB47BC),
      const Color(0xFF26C6DA),
    ];
    final color = colors[index % colors.length];

    return Container(
      width: 48,
      height: 64,
      decoration: BoxDecoration(
        color: AppTheme.panel,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: color.withOpacity(0.4)),
        boxShadow: [
          BoxShadow(color: color.withOpacity(0.1), blurRadius: 8),
        ],
      ),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Q${index + 1}',
            style: AppTheme.monoStyle(
              fontSize: 10,
              color: color,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 4),
          const Icon(Icons.lock_rounded, size: 12, color: AppTheme.textMuted),
        ],
      ),
    );
  }

  Widget _buildActionButtons(
      BuildContext context, PaperProvider paper, QuestionProvider questions) {
    final canGenerate = questions.totalCount >= 30 && !paper.hasPaper && !paper.isGenerating;
    final canSeal = paper.hasPaper && paper.primaryPaper!.status == PaperStatus.draft && !paper.isSealing;
    final canDispatch = paper.hasPaper &&
        paper.primaryPaper!.status == PaperStatus.sealed &&
        !paper.isSealing;

    return Wrap(
      spacing: 12,
      runSpacing: 12,
      children: [
        ElevatedButton.icon(
          onPressed: canGenerate ? () => _generate(context) : null,
          icon: paper.isGenerating
              ? const SizedBox(
                  width: 14,
                  height: 14,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    color: AppTheme.textInverse,
                  ),
                )
              : const Icon(Icons.play_arrow_rounded),
          label: Text(paper.isGenerating ? 'Generating...' : 'Generate Paper'),
        ),
        if (canSeal)
          ElevatedButton.icon(
            onPressed: () => _seal(context),
            icon: const Icon(Icons.lock_rounded),
            label: const Text('Seal Paper'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.secure,
              foregroundColor: Colors.white,
            ),
          ),
        if (canDispatch)
          ElevatedButton.icon(
            onPressed: () => _dispatch(context),
            icon: const Icon(Icons.send_rounded),
            label: const Text('Dispatch to Print Center'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppTheme.warning,
              foregroundColor: AppTheme.textInverse,
            ),
          ),
        if (paper.hasPaper)
          OutlinedButton.icon(
            onPressed: () {
              context.read<PaperProvider>().reset();
            },
            icon: const Icon(Icons.refresh_rounded),
            label: const Text('Reset Paper'),
          ),
      ],
    );
  }

  Widget _buildSignaturePanel(BuildContext context, PaperProvider paper) {
    final p = paper.primaryPaper!;
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: AppTheme.background,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: AppTheme.secure.withOpacity(0.4)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.verified_rounded, size: 14, color: AppTheme.secure),
              const SizedBox(width: 6),
              Text(
                'ADMIN SIGNATURE (SHA-256)',
                style: AppTheme.monoStyle(
                  fontSize: 9,
                  color: AppTheme.secure,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            CryptoService.formatHex(p.adminSignature, groupSize: 8),
            style: AppTheme.monoStyle(
              fontSize: 9,
              color: AppTheme.textSecondary,
            ),
          ),
          const SizedBox(height: 4),
          Row(
            children: [
              Text(
                'STATUS: ',
                style: AppTheme.monoStyle(
                  fontSize: 9,
                  color: AppTheme.textMuted,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                p.status.label.toUpperCase(),
                style: AppTheme.monoStyle(
                  fontSize: 9,
                  color: _statusColor(p.status),
                  fontWeight: FontWeight.w700,
                ),
              ),
              const SizedBox(width: 16),
              Text(
                'QUESTIONS: ${p.questions.length}',
                style: AppTheme.monoStyle(
                  fontSize: 9,
                  color: AppTheme.textMuted,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildPaperPreview(BuildContext context, PaperProvider paper) {
    final p = paper.primaryPaper!;
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.panelGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.description_rounded,
                  size: 16, color: AppTheme.accent),
              const SizedBox(width: 8),
              Text('Paper Preview (First 5 Questions)',
                  style: Theme.of(context).textTheme.titleLarge),
              const Spacer(),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: _statusColor(p.status).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                      color: _statusColor(p.status).withOpacity(0.4)),
                ),
                child: Text(
                  p.status.label.toUpperCase(),
                  style: AppTheme.monoStyle(
                    fontSize: 10,
                    color: _statusColor(p.status),
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(color: AppTheme.border, height: 1),
          const SizedBox(height: 16),
          ...p.questions.take(5).map((q) => Padding(
                padding: const EdgeInsets.only(bottom: 12),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: 28,
                      height: 28,
                      decoration: BoxDecoration(
                        color: AppTheme.accentGlow,
                        shape: BoxShape.circle,
                      ),
                      child: Center(
                        child: Text(
                          '${q.questionNumber}',
                          style: AppTheme.monoStyle(
                            fontSize: 11,
                            color: AppTheme.accent,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            q.text,
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium
                                ?.copyWith(color: AppTheme.textPrimary),
                          ),
                          const SizedBox(height: 4),
                          Wrap(
                            spacing: 12,
                            children: q.options
                                .asMap()
                                .entries
                                .map((e) => Text(
                                      '${_optionLabel(e.key)}) ${e.value}',
                                      style: Theme.of(context)
                                          .textTheme
                                          .bodySmall,
                                    ))
                                .toList(),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              )),
          if (p.questions.length > 5)
            Text(
              '... and ${p.questions.length - 5} more questions',
              style: Theme.of(context).textTheme.bodySmall,
            ),
        ],
      ),
    );
  }

  String _optionLabel(int i) => ['a', 'b', 'c', 'd'][i];

  Color _statusColor(dynamic status) {
    switch (status.toString().split('.').last) {
      case 'draft':      return AppTheme.warning;
      case 'sealed':     return AppTheme.accent;
      case 'dispatched': return AppTheme.secure;
      case 'printed':    return AppTheme.textMuted;
      default:           return AppTheme.textMuted;
    }
  }
}

