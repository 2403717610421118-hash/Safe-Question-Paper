import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../models/exam_paper.dart';
import '../providers/auth_provider.dart';
import '../providers/question_provider.dart';
import '../providers/paper_provider.dart';
import '../providers/audit_provider.dart';
import '../models/audit_log.dart';
import '../data/dummy_questions.dart';
import '../theme/app_theme.dart';
import '../widgets/security_status_bar.dart';
import '../widgets/app_sidebar.dart';
import '../widgets/stat_card.dart';
import '../widgets/audit_log_tile.dart';
import '../widgets/encrypted_blob_tile.dart';
import '../widgets/crypto_key_badge.dart';
import '../services/crypto_service.dart';

class AdminDashboardScreen extends StatefulWidget {
  const AdminDashboardScreen({super.key});

  @override
  State<AdminDashboardScreen> createState() => _AdminDashboardScreenState();
}

class _AdminDashboardScreenState extends State<AdminDashboardScreen> {
  bool _loadingAll = false;

  Future<void> _loadAllSampleQuestions() async {
    final questions = context.read<QuestionProvider>();
    final audit = context.read<AuditProvider>();

    setState(() => _loadingAll = true);

    for (final setter in allSetterProfiles) {
      await questions.loadSampleQuestions(setter);
    }

    setState(() => _loadingAll = false);

    audit.log(
      action: AuditActions.sampleQuestionsLoaded,
      actorId: 'admin',
      actorName: 'Admin Controller',
      actorRole: 'Admin',
      severity: AuditSeverity.success,
      metadata: {'count': '45', 'setters': '3'},
    );
  }

  @override
  Widget build(BuildContext context) {
    final questions = context.watch<QuestionProvider>();
    final paper = context.watch<PaperProvider>();
    final audit = context.watch<AuditProvider>();

    final bySubject = <String, int>{};
    for (final q in questions.allEncryptedQuestions) {
      bySubject[q.subjectCode] = (bySubject[q.subjectCode] ?? 0) + 1;
    }

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Column(
        children: [
          const SecurityStatusBar(),
          Expanded(
            child: Row(
              children: [
                const AppSidebar(currentRoute: '/admin'),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Page header
                        Row(
                          children: [
                            const Icon(Icons.dashboard_rounded,
                                color: AppTheme.accent),
                            const SizedBox(width: 12),
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text('Admin Dashboard',
                                    style: Theme.of(context)
                                        .textTheme
                                        .headlineSmall),
                                Text(
                                  'System overview and control centre',
                                  style: Theme.of(context).textTheme.bodySmall,
                                ),
                              ],
                            ),
                            const Spacer(),
                            if (questions.totalCount == 0)
                              ElevatedButton.icon(
                                onPressed:
                                    _loadingAll ? null : _loadAllSampleQuestions,
                                icon: _loadingAll
                                    ? const SizedBox(
                                        width: 14,
                                        height: 14,
                                        child: CircularProgressIndicator(
                                          strokeWidth: 2,
                                          color: AppTheme.textInverse,
                                        ),
                                      )
                                    : const Icon(Icons.download_rounded),
                                label: const Text('Load All Sample Questions'),
                              ),
                          ],
                        ),
                        const SizedBox(height: 28),

                        // Stats row
                        _buildStatsRow(context, questions, paper),
                        const SizedBox(height: 28),

                        // Two-column layout: encrypted vault + setters
                        Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              flex: 3,
                              child: _buildQuestionVault(context, questions),
                            ),
                            const SizedBox(width: 20),
                            Expanded(
                              flex: 2,
                              child: Column(
                                children: [
                                  _buildSetterProfiles(context, questions),
                                  const SizedBox(height: 20),
                                  _buildPaperActions(context, questions, paper),
                                ],
                              ),
                            ),
                          ],
                        ),
                        const SizedBox(height: 28),

                        // Audit log
                        _buildAuditLog(context, audit),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatsRow(context, questions, paper) {
    return LayoutBuilder(builder: (ctx, constraints) {
      return Wrap(
        spacing: 16,
        runSpacing: 16,
        children: [
          SizedBox(
            width: (constraints.maxWidth - 48) / 4,
            child: StatCard(
              value: '${allSetterProfiles.length}',
              label: 'Active Setters',
              icon: Icons.group_rounded,
              accentColor: AppTheme.accent,
            ),
          ),
          SizedBox(
            width: (constraints.maxWidth - 48) / 4,
            child: StatCard(
              value: '${questions.totalCount}',
              label: 'Questions Encrypted',
              icon: Icons.lock_rounded,
              accentColor: AppTheme.secure,
            ),
          ),
          SizedBox(
            width: (constraints.maxWidth - 48) / 4,
            child: StatCard(
              value: paper.hasPaper ? '1' : '0',
              label: 'Papers Generated',
              icon: Icons.description_rounded,
              accentColor: AppTheme.warning,
              subtitle: paper.hasPaper
                  ? paper.primaryPaper!.status.label.toUpperCase()
                  : null,
            ),
          ),
          SizedBox(
            width: (constraints.maxWidth - 48) / 4,
            child: StatCard(
              value: paper.hasBackup ? '1' : '0',
              label: 'Backup Papers',
              icon: Icons.copy_all_rounded,
              accentColor: const Color(0xFF26C6DA),
            ),
          ),
        ],
      );
    });
  }

  Widget _buildQuestionVault(context, questions) {
    final all = questions.allEncryptedQuestions;
    return _card(
      context,
      title: 'Encrypted Question Vault',
      subtitle: '${all.length} blobs — plaintext never stored',
      icon: Icons.lock_outline_rounded,
      child: all.isEmpty
          ? _emptyVault(context)
          : SizedBox(
              height: 400,
              child: ListView.builder(
                itemCount: all.length,
                itemBuilder: (ctx, i) =>
                    EncryptedBlobTile(question: all[i], index: i),
              ),
            ),
    );
  }

  Widget _buildSetterProfiles(context, questions) {
    return _card(
      context,
      title: 'Setter Profiles',
      subtitle: 'Public key fingerprints',
      icon: Icons.people_outline_rounded,
      child: Column(
        children: allSetterProfiles.map((s) {
          final count = questions.questionsForSetter(s.id).length;
          return Padding(
            padding: const EdgeInsets.only(bottom: 12),
            child: Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.background,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: AppTheme.border),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.person_rounded,
                          size: 16, color: AppTheme.accent),
                      const SizedBox(width: 8),
                      Expanded(
                        child: Text(
                          s.name,
                          style: Theme.of(context)
                              .textTheme
                              .labelLarge
                              ?.copyWith(color: AppTheme.textPrimary),
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: AppTheme.accentGlow,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(
                          '$count Q',
                          style: AppTheme.monoStyle(
                            fontSize: 9,
                            color: AppTheme.accent,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(s.subjectName,
                      style: Theme.of(context).textTheme.labelSmall),
                  const SizedBox(height: 8),
                  CryptoKeyBadge(
                    fingerprint: s.fingerprint,
                    compact: true,
                  ),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildPaperActions(context, questions, PaperProvider paper) {
    return _card(
      context,
      title: 'Paper Actions',
      subtitle: 'Generate, seal, and dispatch',
      icon: Icons.settings_rounded,
      child: Column(
        children: [
          _actionButton(
            context,
            label: 'Generate Paper',
            icon: Icons.shuffle_rounded,
            color: AppTheme.accent,
            enabled: questions.totalCount >= 30 && !paper.hasPaper,
            onTap: () => context.go('/admin/generate'),
          ),
          const SizedBox(height: 10),
          _actionButton(
            context,
            label: 'Security Monitor',
            icon: Icons.monitor_heart_rounded,
            color: AppTheme.secure,
            enabled: true,
            onTap: () => context.go('/admin/security'),
          ),
          const SizedBox(height: 10),
          _actionButton(
            context,
            label: 'Generate Backup',
            icon: Icons.copy_all_rounded,
            color: const Color(0xFF26C6DA),
            enabled: paper.hasPaper && paper.primaryPaper!.status.isLocked,
            onTap: () => context.go('/admin/backup'),
          ),
          if (questions.totalCount < 30) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: AppTheme.warning.withOpacity(0.08),
                borderRadius: BorderRadius.circular(8),
                border:
                    Border.all(color: AppTheme.warning.withOpacity(0.3)),
              ),
              child: Row(
                children: [
                  const Icon(Icons.warning_amber_rounded,
                      size: 14, color: AppTheme.warning),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Text(
                      'Need ≥30 questions. Currently ${questions.totalCount}.\nClick "Load All Sample Questions" above.',
                      style: Theme.of(context).textTheme.labelSmall?.copyWith(
                            color: AppTheme.warning,
                          ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildAuditLog(context, audit) {
    final logs = audit.logs.take(10).toList();
    return _card(
      context,
      title: 'Audit Log',
      subtitle: '${audit.logs.length} events logged',
      icon: Icons.history_rounded,
      child: logs.isEmpty
          ? Padding(
              padding: const EdgeInsets.all(20),
              child: Text('No events yet',
                  style: Theme.of(context).textTheme.bodySmall),
            )
          : Column(
              children:
                  logs.asMap().entries.map((e) => AuditLogTile(log: e.value, isFirst: e.key == 0)).toList(),
            ),
    );
  }

  Widget _card(
    BuildContext context, {
    required String title,
    required String subtitle,
    required IconData icon,
    required Widget child,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 0),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: AppTheme.panelGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 18, color: AppTheme.accent),
              const SizedBox(width: 10),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: Theme.of(context).textTheme.titleLarge),
                  Text(subtitle,
                      style: Theme.of(context).textTheme.labelSmall),
                ],
              ),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(color: AppTheme.border, height: 1),
          const SizedBox(height: 16),
          child,
        ],
      ),
    );
  }

  Widget _actionButton(
    BuildContext context, {
    required String label,
    required IconData icon,
    required Color color,
    required bool enabled,
    required VoidCallback onTap,
  }) {
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: enabled ? onTap : null,
        icon: Icon(icon, size: 16),
        label: Text(label),
        style: OutlinedButton.styleFrom(
          foregroundColor: color,
          side: BorderSide(color: enabled ? color.withOpacity(0.5) : AppTheme.border),
          padding: const EdgeInsets.symmetric(vertical: 12),
        ),
      ),
    );
  }

  Widget _emptyVault(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 32),
      child: Center(
        child: Column(
          children: [
            const Icon(Icons.inbox_rounded,
                color: AppTheme.textMuted, size: 40),
            const SizedBox(height: 12),
            Text('No encrypted questions yet',
                style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 6),
            Text(
              'Ask setters to submit, or use "Load All Sample Questions"',
              style: Theme.of(context).textTheme.bodySmall,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
