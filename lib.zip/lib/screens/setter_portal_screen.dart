import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/question_provider.dart';
import '../providers/audit_provider.dart';
import '../models/audit_log.dart';
import '../theme/app_theme.dart';
import '../widgets/encrypted_blob_tile.dart';
import '../widgets/crypto_key_badge.dart';
import '../widgets/security_status_bar.dart';
import '../widgets/app_sidebar.dart';
import '../services/crypto_service.dart';

class SetterPortalScreen extends StatefulWidget {
  const SetterPortalScreen({super.key});

  @override
  State<SetterPortalScreen> createState() => _SetterPortalScreenState();
}

class _SetterPortalScreenState extends State<SetterPortalScreen> {
  bool _loadingAll = false;

  Future<void> _loadSampleQuestions() async {
    final auth = context.read<AuthProvider>();
    final questions = context.read<QuestionProvider>();
    final audit = context.read<AuditProvider>();
    final profile = auth.currentSetterProfile!;

    setState(() {
      _loadingAll = true;
    });

    final raw = questions.getAllRaw();
    final alreadyLoaded = raw.where((q) => q.setterId == profile.id).length;
    if (alreadyLoaded > 0) {
      setState(() => _loadingAll = false);
      _showSnack('Sample questions already loaded for ${profile.name}');
      return;
    }

    await questions.loadSampleQuestions(profile);

    setState(() => _loadingAll = false);

    audit.log(
      action: AuditActions.sampleQuestionsLoaded,
      actorId: profile.id,
      actorName: profile.name,
      actorRole: 'Setter',
      severity: AuditSeverity.success,
      metadata: {
        'subject': profile.subjectName,
        'count': '15',
      },
    );

    _showSnack('15 sample questions encrypted and uploaded ✅');
  }

  void _showSnack(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(msg), duration: const Duration(seconds: 2)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final questions = context.watch<QuestionProvider>();
    final profile = auth.currentSetterProfile;

    if (profile == null) {
      return const Scaffold(
        body: Center(child: Text('No setter profile selected')),
      );
    }

    final myQuestions = questions.questionsForSetter(profile.id);

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Column(
        children: [
          const SecurityStatusBar(),
          Expanded(
            child: Row(
              children: [
                const AppSidebar(currentRoute: '/setter'),
                Expanded(
                  child: _buildContent(context, profile, myQuestions),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContent(BuildContext context, profile, myQuestions) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Header
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 18),
          decoration: const BoxDecoration(
            border: Border(bottom: BorderSide(color: AppTheme.border)),
          ),
          child: Row(
            children: [
              const Icon(Icons.edit_note_rounded, color: AppTheme.accent),
              const SizedBox(width: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Question Setter Portal',
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                  Text(
                    'Logged in as ${profile.name} — ${profile.subjectName}',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
              const Spacer(),
              ElevatedButton.icon(
                onPressed: _loadingAll ? null : _loadSampleQuestions,
                icon: _loadingAll
                    ? const SizedBox(
                        width: 14,
                        height: 14,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          color: AppTheme.textInverse,
                        ),
                      )
                    : const Icon(Icons.download_rounded),
                label: Text(_loadingAll
                    ? 'Encrypting...'
                    : 'Load Sample Questions (15)'),
              ),
            ],
          ),
        ),

        Expanded(
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Left: Key info panel
              _buildKeyPanel(context, profile),
              // Right: Question list
              Expanded(child: _buildQuestionList(context, myQuestions)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildKeyPanel(BuildContext context, profile) {
    return Container(
      width: 280,
      padding: const EdgeInsets.all(20),
      decoration: const BoxDecoration(
        border: Border(right: BorderSide(color: AppTheme.border)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'CRYPTOGRAPHIC IDENTITY',
            style: AppTheme.monoStyle(
              fontSize: 10,
              color: AppTheme.accent,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 16),
          _infoRow('Name', profile.name),
          _infoRow('Subject', profile.subjectName),
          _infoRow('Setter ID', profile.id),
          const SizedBox(height: 16),
          const Divider(color: AppTheme.border),
          const SizedBox(height: 16),
          Text(
            'PUBLIC KEY',
            style: AppTheme.monoStyle(
              fontSize: 10,
              color: AppTheme.accent,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          CryptoKeyBadge(fingerprint: profile.fingerprint),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppTheme.background,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppTheme.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'FULL PUBLIC KEY (SHA-256)',
                  style: AppTheme.monoStyle(
                      fontSize: 8,
                      color: AppTheme.accent,
                      fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 4),
                Text(
                  CryptoService.formatHex(profile.publicKeyHex, groupSize: 8),
                  style: AppTheme.monoStyle(fontSize: 9, color: AppTheme.textSecondary),
                ),
              ],
            ),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppTheme.background,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppTheme.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'PRIVATE KEY (PREVIEW — 8 bytes)',
                  style: AppTheme.monoStyle(
                      fontSize: 8,
                      color: AppTheme.danger,
                      fontWeight: FontWeight.w700),
                ),
                const SizedBox(height: 4),
                Text(
                  profile.privateKeyPreview,
                  style: AppTheme.monoStyle(fontSize: 9, color: AppTheme.danger),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          const Divider(color: AppTheme.border),
          const SizedBox(height: 16),
          Text(
            'HOW ENCRYPTION WORKS',
            style: AppTheme.monoStyle(
              fontSize: 10,
              color: AppTheme.textMuted,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 8),
          _stepBadge('1', 'Each question is serialised to JSON'),
          _stepBadge('2', 'AES-256-GCM encrypts the JSON'),
          _stepBadge('3', 'AES key is XOR-wrapped with your private key'),
          _stepBadge('4', 'Only admin can unwrap and decrypt'),
        ],
      ),
    );
  }

  Widget _buildQuestionList(BuildContext context, List myQuestions) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'My Encrypted Questions',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(width: 12),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppTheme.accentGlow,
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Text(
                  '${myQuestions.length}',
                  style: AppTheme.monoStyle(
                    fontSize: 12,
                    color: AppTheme.accent,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Text(
            'Questions are stored as AES-256-GCM ciphertext — only metadata is visible below',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 16),
          if (myQuestions.isEmpty)
            Expanded(child: _buildEmptyState(context))
          else
            Expanded(
              child: ListView.builder(
                itemCount: myQuestions.length,
                itemBuilder: (ctx, i) => EncryptedBlobTile(
                  question: myQuestions[i],
                  index: i,
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            width: 64,
            height: 64,
            decoration: BoxDecoration(
              color: AppTheme.accentGlow,
              borderRadius: BorderRadius.circular(16),
            ),
            child: const Icon(Icons.upload_rounded, color: AppTheme.accent, size: 30),
          ),
          const SizedBox(height: 16),
          Text('No questions yet',
              style: Theme.of(context).textTheme.headlineSmall),
          const SizedBox(height: 8),
          Text(
            'Click "Load Sample Questions" to encrypt and submit\n15 pre-filled questions instantly',
            style: Theme.of(context).textTheme.bodyMedium,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _infoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 70,
            child: Text(
              label,
              style: AppTheme.monoStyle(fontSize: 10, color: AppTheme.textMuted),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: AppTheme.monoStyle(fontSize: 10, color: AppTheme.textPrimary),
            ),
          ),
        ],
      ),
    );
  }

  Widget _stepBadge(String num, String text) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 18,
            height: 18,
            decoration: BoxDecoration(
              color: AppTheme.accentGlow,
              shape: BoxShape.circle,
              border: Border.all(color: AppTheme.accent.withOpacity(0.4)),
            ),
            child: Center(
              child: Text(
                num,
                style: AppTheme.monoStyle(
                  fontSize: 9,
                  color: AppTheme.accent,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: AppTheme.monoStyle(fontSize: 9, color: AppTheme.textSecondary),
            ),
          ),
        ],
      ),
    );
  }
}
