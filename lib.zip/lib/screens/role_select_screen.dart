import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../models/user_role.dart';
import '../providers/auth_provider.dart';
import '../theme/app_theme.dart';

class RoleSelectScreen extends StatelessWidget {
  const RoleSelectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(40),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              InkWell(
                onTap: () => context.go('/'),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.arrow_back_rounded,
                        size: 16, color: AppTheme.textMuted),
                    const SizedBox(width: 6),
                    Text('Back to Home',
                        style: Theme.of(context).textTheme.labelMedium),
                  ],
                ),
              ),
              const SizedBox(height: 40),
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  gradient: AppTheme.accentGradient,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: AppTheme.accent.withOpacity(0.35),
                      blurRadius: 20,
                    ),
                  ],
                ),
                child: const Icon(Icons.security, color: Colors.white, size: 26),
              ),
              const SizedBox(height: 20),
              Text(
                'Select Your Role',
                style: Theme.of(context).textTheme.displaySmall,
              ),
              const SizedBox(height: 8),
              Text(
                'Choose how you\'re accessing the SecureExam system',
                style: Theme.of(context).textTheme.bodyMedium,
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 48),
              LayoutBuilder(builder: (context, constraints) {
                return Wrap(
                  spacing: 20,
                  runSpacing: 20,
                  alignment: WrapAlignment.center,
                  children: UserRole.values
                      .map((r) => _RoleCard(role: r))
                      .toList(),
                );
              }),
              const SizedBox(height: 40),
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: AppTheme.surface,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: AppTheme.border),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.info_outline,
                        size: 16, color: AppTheme.accent),
                    const SizedBox(width: 10),
                    Flexible(
                      child: Text(
                        'Demo tip: Start as a Question Setter → load sample questions → switch to Admin to generate → then Print Officer to unlock.',
                        style: Theme.of(context)
                            .textTheme
                            .bodySmall
                            ?.copyWith(height: 1.5),
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _RoleCard extends StatefulWidget {
  final UserRole role;
  const _RoleCard({required this.role});

  @override
  State<_RoleCard> createState() => _RoleCardState();
}

class _RoleCardState extends State<_RoleCard> {
  bool _hovered = false;

  @override
  Widget build(BuildContext context) {
    final r = widget.role;
    final (color, gradient) = _roleStyle(r);

    return MouseRegion(
      onEnter: (_) => setState(() => _hovered = true),
      onExit: (_) => setState(() => _hovered = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        width: 280,
        padding: const EdgeInsets.all(28),
        decoration: BoxDecoration(
          gradient: _hovered
              ? LinearGradient(
                  colors: [color.withOpacity(0.1), AppTheme.panel],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                )
              : AppTheme.panelGradient,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: _hovered ? color.withOpacity(0.5) : AppTheme.border,
            width: _hovered ? 1.5 : 1,
          ),
          boxShadow: _hovered
              ? [BoxShadow(color: color.withOpacity(0.15), blurRadius: 24, spreadRadius: 1)]
              : [],
        ),
        child: InkWell(
          onTap: () => _onSelect(context, r),
          borderRadius: BorderRadius.circular(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Container(
                width: 52,
                height: 52,
                decoration: BoxDecoration(
                  gradient: gradient,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: _hovered
                      ? [BoxShadow(color: color.withOpacity(0.3), blurRadius: 12)]
                      : [],
                ),
                child: Center(
                  child: Text(r.icon, style: const TextStyle(fontSize: 24)),
                ),
              ),
              const SizedBox(height: 18),
              Text(
                r.displayName,
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      color: AppTheme.textPrimary,
                    ),
              ),
              const SizedBox(height: 8),
              Text(
                r.description,
                style: Theme.of(context)
                    .textTheme
                    .bodyMedium
                    ?.copyWith(height: 1.5),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Text(
                    'Biometric required',
                    style: AppTheme.monoStyle(
                      fontSize: 10,
                      color: color,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const Spacer(),
                  AnimatedOpacity(
                    opacity: _hovered ? 1 : 0,
                    duration: const Duration(milliseconds: 200),
                    child:
                        Icon(Icons.arrow_forward_rounded, size: 16, color: color),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _onSelect(BuildContext context, UserRole role) {
    context.read<AuthProvider>().setRole(role);
    context.go('/biometric/${role.name}');
  }

  (Color, LinearGradient) _roleStyle(UserRole r) {
    switch (r) {
      case UserRole.setter:
        return (
          AppTheme.accent,
          AppTheme.accentGradient,
        );
      case UserRole.admin:
        return (
          AppTheme.secure,
          AppTheme.secureGradient,
        );
      case UserRole.printOfficer:
        return (
          AppTheme.warning,
          const LinearGradient(
            colors: [Color(0xFFFFD600), Color(0xFFFF8F00)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        );
    }
  }
}
