import 'package:flutter/material.dart';
import 'package:printing/printing.dart';
import 'package:provider/provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import '../providers/paper_provider.dart';
import '../providers/audit_provider.dart';
import '../models/audit_log.dart';
import '../models/exam_paper.dart';
import '../services/biometric_service.dart';
import '../theme/app_theme.dart';
import '../widgets/security_status_bar.dart';
import '../widgets/app_sidebar.dart';

class PrintCenterScreen extends StatefulWidget {
  const PrintCenterScreen({super.key});

  @override
  State<PrintCenterScreen> createState() => _PrintCenterScreenState();
}

class _PrintCenterScreenState extends State<PrintCenterScreen>
    with TickerProviderStateMixin {
  final _otpController = TextEditingController();
  late AnimationController _decryptController;
  late AnimationController _unlockController;

  bool _otpVerified = false;
  bool _biometricVerified = false;
  bool _biometricScanning = false;
  double _biometricProgress = 0;
  String _otpError = '';

  @override
  void initState() {
    super.initState();
    _decryptController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );
    _unlockController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 600),
    );
  }

  @override
  void dispose() {
    _otpController.dispose();
    _decryptController.dispose();
    _unlockController.dispose();
    super.dispose();
  }

  void _verifyOtp() {
    if (BiometricService.validateOtp(_otpController.text)) {
      setState(() {
        _otpVerified = true;
        _otpError = '';
      });
    } else {
      setState(() => _otpError = 'Invalid OTP. Hint: use 123456');
    }
  }

  Future<void> _scanBiometric(BuildContext context) async {
    setState(() {
      _biometricScanning = true;
      _biometricProgress = 0;
    });

    await BiometricService.scanFingerprint(
      onProgress: (p) {
        if (mounted) setState(() => _biometricProgress = p);
      },
    );

    setState(() {
      _biometricScanning = false;
      _biometricVerified = true;
    });
    _unlockController.forward();

    await Future.delayed(const Duration(milliseconds: 500));
    if (!mounted) return;
    await _decryptPaper(context);
  }

  Future<void> _decryptPaper(BuildContext context) async {
    final paper = context.read<PaperProvider>();
    final audit = context.read<AuditProvider>();

    setState(() {});
    _decryptController.repeat(reverse: false);

    await paper.unlockPaper();

    _decryptController.stop();
    setState(() {});

    audit.log(
      action: AuditActions.printCenterUnlock,
      actorId: 'print_officer',
      actorName: 'Print Center Officer',
      actorRole: 'PrintOfficer',
      severity: AuditSeverity.success,
      metadata: {'method': 'OTP + FINGERPRINT'},
    );
    audit.log(
      action: AuditActions.paperDecrypted,
      actorId: 'print_officer',
      actorName: 'Print Center Officer',
      actorRole: 'PrintOfficer',
      severity: AuditSeverity.success,
    );
  }

  Future<void> _printPaper(BuildContext context) async {
    final paper = context.read<PaperProvider>();
    final p = paper.primaryPaper!;
    final audit = context.read<AuditProvider>();

    final doc = pw.Document();
    doc.addPage(
      pw.MultiPage(
        pageFormat: PdfPageFormat.a4,
        margin: const pw.EdgeInsets.all(40),
        build: (ctx) => [
          pw.Text(
            p.title,
            style: pw.TextStyle(fontSize: 18, fontWeight: pw.FontWeight.bold),
          ),
          pw.SizedBox(height: 4),
          pw.Text('Subject: ${p.subjectName}', style: const pw.TextStyle(fontSize: 11)),
          pw.Text(
            'Seed: ${p.seed.substring(0, 16).toUpperCase()}...',
            style: const pw.TextStyle(fontSize: 8),
          ),
          pw.Text(
            'Signature: ${p.adminSignature.substring(0, 32).toUpperCase()}...',
            style: const pw.TextStyle(fontSize: 8),
          ),
          pw.SizedBox(height: 4),
          pw.Divider(),
          pw.SizedBox(height: 8),
          pw.Text('STRICTLY CONFIDENTIAL — PRINT CENTER COPY',
              style: pw.TextStyle(
                fontSize: 10,
                fontWeight: pw.FontWeight.bold,
                color: PdfColors.red,
              )),
          pw.SizedBox(height: 16),
          ...p.questions.map(
            (q) => pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Text(
                  '${q.questionNumber}. ${q.text}',
                  style: pw.TextStyle(
                      fontSize: 11, fontWeight: pw.FontWeight.bold),
                ),
                pw.SizedBox(height: 4),
                ...q.options.asMap().entries.map(
                  (e) => pw.Padding(
                    padding: const pw.EdgeInsets.only(left: 16, bottom: 2),
                    child: pw.Text(
                      '${['a', 'b', 'c', 'd'][e.key]}) ${e.value}',
                      style: const pw.TextStyle(fontSize: 10),
                    ),
                  ),
                ),
                pw.SizedBox(height: 10),
              ],
            ),
          ),
        ],
      ),
    );

    await Printing.layoutPdf(onLayout: (_) => doc.save());

    await paper.markPrinted();
    audit.log(
      action: AuditActions.paperPrinted,
      actorId: 'print_officer',
      actorName: 'Print Center Officer',
      actorRole: 'PrintOfficer',
      severity: AuditSeverity.success,
      metadata: {'copies': '1', 'format': 'A4'},
    );
  }

  @override
  Widget build(BuildContext context) {
    final paper = context.watch<PaperProvider>();

    return Scaffold(
      backgroundColor: AppTheme.background,
      body: Column(
        children: [
          const SecurityStatusBar(),
          Expanded(
            child: Row(
              children: [
                const AppSidebar(currentRoute: '/print'),
                Expanded(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(28),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        _buildHeader(context),
                        const SizedBox(height: 24),
                        if (!paper.hasPaper || paper.primaryPaper!.status == PaperStatus.draft)
                          _buildNoPaperState(context)
                        else if (!paper.isUnlocked)
                          _buildAuthFlow(context, paper)
                        else
                          _buildPaperViewer(context, paper),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    return Row(
      children: [
        const Icon(Icons.print_rounded, color: AppTheme.warning),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Print Center Portal',
                style: Theme.of(context).textTheme.headlineSmall),
            Text('Secure paper unlock and printing',
                style: Theme.of(context).textTheme.bodySmall),
          ],
        ),
      ],
    );
  }

  Widget _buildNoPaperState(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          const SizedBox(height: 60),
          Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: AppTheme.warning.withOpacity(0.1),
              shape: BoxShape.circle,
              border: Border.all(color: AppTheme.warning.withOpacity(0.3)),
            ),
            child: const Icon(Icons.lock_clock_rounded,
                color: AppTheme.warning, size: 36),
          ),
          const SizedBox(height: 20),
          Text('No Sealed Paper Available',
              style: Theme.of(context).textTheme.headlineMedium),
          const SizedBox(height: 8),
          Text(
            'The Admin must generate and seal a paper before it can be received here.',
            style: Theme.of(context).textTheme.bodyMedium,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }

  Widget _buildAuthFlow(BuildContext context, PaperProvider paper) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Expanded(flex: 2, child: _buildAuthPanel(context, paper)),
        const SizedBox(width: 24),
        Expanded(flex: 3, child: _buildSealedPaperPanel(context, paper)),
      ],
    );
  }

  Widget _buildAuthPanel(BuildContext context, PaperProvider paper) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: AppTheme.panelGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.key_rounded, size: 16, color: AppTheme.warning),
              const SizedBox(width: 8),
              Text('Authentication Required',
                  style: Theme.of(context).textTheme.titleLarge),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            'Two-factor verification: OTP + Biometric',
            style: Theme.of(context).textTheme.labelSmall,
          ),
          const SizedBox(height: 20),
          const Divider(color: AppTheme.border, height: 1),
          const SizedBox(height: 20),

          // Step 1: OTP
          _authStep(
            context,
            step: 1,
            label: 'Enter OTP',
            done: _otpVerified,
            child: _otpVerified
                ? Row(
                    children: [
                      const Icon(Icons.check_circle_rounded,
                          color: AppTheme.secure, size: 16),
                      const SizedBox(width: 8),
                      Text('OTP Verified',
                          style: Theme.of(context)
                              .textTheme
                              .labelLarge
                              ?.copyWith(color: AppTheme.secure)),
                    ],
                  )
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Demo hint: enter 123456',
                        style: AppTheme.monoStyle(
                          fontSize: 9,
                          color: AppTheme.textMuted,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Row(
                        children: [
                          Expanded(
                            child: TextField(
                              controller: _otpController,
                              keyboardType: TextInputType.number,
                              maxLength: 6,
                              style: AppTheme.monoStyle(
                                fontSize: 18,
                                color: AppTheme.textPrimary,
                                fontWeight: FontWeight.w700,
                              ),
                              decoration: const InputDecoration(
                                hintText: '000000',
                                counterText: '',
                              ),
                            ),
                          ),
                          const SizedBox(width: 10),
                          ElevatedButton(
                            onPressed: _verifyOtp,
                            child: const Text('Verify'),
                          ),
                        ],
                      ),
                      if (_otpError.isNotEmpty) ...[
                        const SizedBox(height: 6),
                        Text(_otpError,
                            style: const TextStyle(
                                color: AppTheme.danger, fontSize: 12)),
                      ],
                    ],
                  ),
          ),

          const SizedBox(height: 20),

          // Step 2: Biometric
          _authStep(
            context,
            step: 2,
            label: 'Biometric Scan',
            done: _biometricVerified,
            child: !_otpVerified
                ? Text(
                    'Complete OTP verification first',
                    style: Theme.of(context)
                        .textTheme
                        .labelSmall
                        ?.copyWith(color: AppTheme.textMuted),
                  )
                : _biometricVerified
                    ? Row(
                        children: [
                          const Icon(Icons.check_circle_rounded,
                              color: AppTheme.secure, size: 16),
                          const SizedBox(width: 8),
                          Text('Fingerprint Verified',
                              style: Theme.of(context)
                                  .textTheme
                                  .labelLarge
                                  ?.copyWith(color: AppTheme.secure)),
                        ],
                      )
                    : Column(
                        children: [
                          if (_biometricScanning) ...[
                            ClipRRect(
                              borderRadius: BorderRadius.circular(4),
                              child: LinearProgressIndicator(
                                value: _biometricProgress,
                                minHeight: 4,
                                backgroundColor: AppTheme.border,
                                valueColor: const AlwaysStoppedAnimation(
                                    AppTheme.warning),
                              ),
                            ),
                            const SizedBox(height: 8),
                            Text(
                              'Scanning... ${(_biometricProgress * 100).round()}%',
                              style: AppTheme.monoStyle(
                                fontSize: 10,
                                color: AppTheme.warning,
                              ),
                            ),
                          ] else
                            ElevatedButton.icon(
                              onPressed: () => _scanBiometric(context),
                              icon: const Icon(Icons.fingerprint),
                              label: const Text('Scan Fingerprint'),
                              style: ElevatedButton.styleFrom(
                                backgroundColor: AppTheme.warning,
                                foregroundColor: AppTheme.textInverse,
                              ),
                            ),
                        ],
                      ),
          ),
        ],
      ),
    );
  }

  Widget _authStep(
    BuildContext context, {
    required int step,
    required String label,
    required bool done,
    required Widget child,
  }) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 28,
          height: 28,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: done ? AppTheme.secure : AppTheme.accentGlow,
            border: Border.all(color: done ? AppTheme.secure : AppTheme.accent),
          ),
          child: Center(
            child: done
                ? const Icon(Icons.check_rounded,
                    size: 14, color: Colors.white)
                : Text(
                    '$step',
                    style: AppTheme.monoStyle(
                      fontSize: 12,
                      color: AppTheme.accent,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: Theme.of(context)
                    .textTheme
                    .titleMedium
                    ?.copyWith(color: AppTheme.textPrimary),
              ),
              const SizedBox(height: 8),
              child,
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSealedPaperPanel(BuildContext context, PaperProvider paper) {
    final p = paper.primaryPaper!;
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: AppTheme.panelGradient,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: AppTheme.accent.withOpacity(0.3)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Icon(Icons.inbox_rounded, size: 16, color: AppTheme.accent),
              const SizedBox(width: 8),
              Text('Sealed Paper — Incoming',
                  style: Theme.of(context).textTheme.titleLarge),
              const Spacer(),
              _statusBadge(p.status),
            ],
          ),
          const SizedBox(height: 16),
          const Divider(color: AppTheme.border, height: 1),
          const SizedBox(height: 16),
          // Paper metadata
          _metaRow(context, 'Paper ID', p.id),
          _metaRow(context, 'Title', p.title),
          _metaRow(context, 'Questions', '${p.questions.length}'),
          _metaRow(context, 'Generated', _formatDt(p.generatedAt)),
          _metaRow(
              context,
              'Signature',
              '${p.adminSignature.substring(0, 32).toUpperCase()}...'),
          _metaRow(
              context,
              'Seed',
              '${p.seed.substring(0, 32).toUpperCase()}...'),
          const SizedBox(height: 20),
          // Ciphertext visualization
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: AppTheme.background,
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: AppTheme.border),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'SEALED PACKET (SIMULATED)',
                  style: AppTheme.monoStyle(
                    fontSize: 9,
                    color: AppTheme.accent,
                    fontWeight: FontWeight.w700,
                  ),
                ),
                const SizedBox(height: 6),
                Text(
                  '████ ████ ████ ████ ████ ████ ████ ████\n'
                  '████ ████ ████ ████ ████ ████ ████ ████\n'
                  '████ ████ ████ ████ ████ ████ ████ ████',
                  style: AppTheme.monoStyle(
                    fontSize: 11,
                    color: AppTheme.textMuted,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '[AES-256-GCM encrypted — unlock to view]',
                  style: AppTheme.monoStyle(
                    fontSize: 9,
                    color: AppTheme.textMuted,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPaperViewer(BuildContext context, PaperProvider paper) {
    final p = paper.primaryPaper!;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Success banner
        Container(
          width: double.infinity,
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            color: AppTheme.secure.withOpacity(0.08),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(color: AppTheme.secure.withOpacity(0.4)),
          ),
          child: Row(
            children: [
              const Icon(Icons.lock_open_rounded, color: AppTheme.secure),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '🔓 Paper Decrypted Successfully',
                      style: Theme.of(context)
                          .textTheme
                          .titleLarge
                          ?.copyWith(color: AppTheme.secure),
                    ),
                    Text(
                      'OTP + Biometric verified. This session is logged and monitored.',
                      style: Theme.of(context).textTheme.labelSmall,
                    ),
                  ],
                ),
              ),
              ElevatedButton.icon(
                onPressed: () => _printPaper(context),
                icon: const Icon(Icons.print_rounded),
                label: const Text('Print / PDF'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.warning,
                  foregroundColor: AppTheme.textInverse,
                ),
              ),
            ],
          ),
        ),
        const SizedBox(height: 20),
        // Formatted paper
        Container(
          padding: const EdgeInsets.all(32),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12),
            boxShadow: [
              BoxShadow(
                  color: Colors.black.withOpacity(0.2), blurRadius: 20),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Watermark header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'STRICTLY CONFIDENTIAL',
                    style: TextStyle(
                      fontSize: 10,
                      color: Colors.red.shade700,
                      fontWeight: FontWeight.w700,
                      letterSpacing: 1.2,
                    ),
                  ),
                  Text(
                    'CENTER: ${p.id}',
                    style: const TextStyle(
                        fontSize: 9, color: Color(0xFF888888)),
                  ),
                ],
              ),
              const Divider(),
              const SizedBox(height: 8),
              Center(
                child: Column(
                  children: [
                    Text(
                      p.title,
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.w800,
                        color: Colors.black,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Time: 3 hours | Total Marks: ${p.questions.length} | Date: ${_formatDate(p.generatedAt)}',
                      style: const TextStyle(
                          fontSize: 11, color: Color(0xFF444444)),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 8),
              const Divider(thickness: 2),
              const SizedBox(height: 16),
              const Text(
                'INSTRUCTIONS: Attempt all questions. Each question carries 1 mark. No negative marking.',
                style: TextStyle(
                    fontSize: 11, color: Color(0xFF333333)),
              ),
              const SizedBox(height: 20),
              ...p.questions.map(
                (q) => Padding(
                  padding: const EdgeInsets.only(bottom: 18),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${q.questionNumber}. ${q.text}',
                        style: const TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: Colors.black,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Wrap(
                        spacing: 24,
                        runSpacing: 4,
                        children: q.options
                            .asMap()
                            .entries
                            .map(
                              (e) => SizedBox(
                                width: 300,
                                child: Text(
                                  '(${['a', 'b', 'c', 'd'][e.key]})  ${e.value}',
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: Color(0xFF333333),
                                  ),
                                ),
                              ),
                            )
                            .toList(),
                      ),
                    ],
                  ),
                ),
              ),
              const Divider(),
              const SizedBox(height: 8),
              Text(
                '*** END OF PAPER ***\nSeed: ${p.seed.substring(0, 32).toUpperCase()}\nSignature: ${p.adminSignature.substring(0, 32).toUpperCase()}',
                style: const TextStyle(fontSize: 8, color: Color(0xFF999999)),
                textAlign: TextAlign.center,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _metaRow(BuildContext context, String label, String value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 90,
            child: Text(
              label,
              style: AppTheme.monoStyle(
                fontSize: 10,
                color: AppTheme.textMuted,
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: AppTheme.monoStyle(
                fontSize: 10,
                color: AppTheme.textPrimary,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _statusBadge(PaperStatus status) {
    final (color, label) = switch (status) {
      PaperStatus.sealed     => (AppTheme.accent, 'SEALED'),
      PaperStatus.dispatched => (AppTheme.secure, 'DISPATCHED'),
      PaperStatus.printed    => (AppTheme.textMuted, 'PRINTED'),
      PaperStatus.draft      => (AppTheme.warning, 'DRAFT'),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.4)),
      ),
      child: Text(
        label,
        style: AppTheme.monoStyle(
          fontSize: 10,
          color: color,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }

  String _formatDt(DateTime dt) {
    final d = '${dt.day.toString().padLeft(2, '0')}/${dt.month.toString().padLeft(2, '0')}/${dt.year}';
    final t = '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}';
    return '$d $t';
  }

  String _formatDate(DateTime dt) =>
      '${dt.day}/${dt.month}/${dt.year}';
}
