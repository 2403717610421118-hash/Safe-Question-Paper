import 'dart:async';

enum BiometricType { fingerprint, faceId }

class BiometricResult {
  final bool success;
  final String message;
  final BiometricType type;

  const BiometricResult({
    required this.success,
    required this.message,
    required this.type,
  });
}

/// Simulates a biometric authentication gate.
/// Always succeeds after a fixed delay (demo mode).
class BiometricService {
  /// Simulate fingerprint scan — always succeeds after [duration]
  static Future<BiometricResult> scanFingerprint({
    Duration duration = const Duration(seconds: 2),
    void Function(double progress)? onProgress,
  }) async {
    const steps = 20;
    for (var i = 1; i <= steps; i++) {
      await Future.delayed(duration ~/ steps);
      onProgress?.call(i / steps);
    }
    return const BiometricResult(
      success: true,
      message: 'Fingerprint matched — Access granted',
      type: BiometricType.fingerprint,
    );
  }

  /// Simulate face-ID scan — always succeeds after [duration]
  static Future<BiometricResult> scanFaceId({
    Duration duration = const Duration(seconds: 2),
    void Function(double progress)? onProgress,
  }) async {
    const steps = 20;
    for (var i = 1; i <= steps; i++) {
      await Future.delayed(duration ~/ steps);
      onProgress?.call(i / steps);
    }
    return const BiometricResult(
      success: true,
      message: 'Face ID verified — Access granted',
      type: BiometricType.faceId,
    );
  }

  /// Validate the print-center OTP (always "123456" for demo)
  static bool validateOtp(String otp) => otp.trim() == '123456';
}
