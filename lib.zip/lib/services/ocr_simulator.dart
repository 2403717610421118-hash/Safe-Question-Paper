import 'dart:math';
import '../models/question.dart';

class FairnessReport {
  final double overallScore;          // 0.0 – 100.0
  final int totalQuestions;
  final Map<QuestionDifficulty, int> difficultyBreakdown;
  final Map<String, int> topicBreakdown;
  final int printQualityScore;        // 0–100
  final int contentIntegrityScore;    // 0–100
  final int formatComplianceScore;    // 0–100
  final String certificateId;
  final DateTime issuedAt;
  final List<String> scanFindings;

  const FairnessReport({
    required this.overallScore,
    required this.totalQuestions,
    required this.difficultyBreakdown,
    required this.topicBreakdown,
    required this.printQualityScore,
    required this.contentIntegrityScore,
    required this.formatComplianceScore,
    required this.certificateId,
    required this.issuedAt,
    required this.scanFindings,
  });

  bool get passed => overallScore >= 80.0;
}

class OcrSimulatorService {
  static final _rng = Random();

  /// Simulate OCR + AI fairness analysis. Returns after a short delay
  /// to give the UI time to show a progress animation.
  static Future<FairnessReport> runFairnessCheck({
    required List<dynamic> questions, // List<PaperQuestion>
    required Map<String, int> topicBreakdown,
    required Map<dynamic, int> difficultyBreakdown,
  }) async {
    // Simulate async processing time
    await Future.delayed(const Duration(milliseconds: 200));

    final total = questions.length;
    final diff = difficultyBreakdown.map(
      (k, v) => MapEntry(k as QuestionDifficulty, v),
    );

    // Simulate scores with high values (everything is passing in demo)
    final printQ = 92 + _rng.nextInt(8);        // 92–99
    final contentI = 94 + _rng.nextInt(6);      // 94–99
    final formatC = 96 + _rng.nextInt(4);        // 96–99

    final overall = (printQ * 0.3 + contentI * 0.4 + formatC * 0.3);

    final certId = 'CERT-${DateTime.now().millisecondsSinceEpoch.toRadixString(16).toUpperCase()}';

    return FairnessReport(
      overallScore: overall,
      totalQuestions: total,
      difficultyBreakdown: diff,
      topicBreakdown: topicBreakdown,
      printQualityScore: printQ,
      contentIntegrityScore: contentI,
      formatComplianceScore: formatC,
      certificateId: certId,
      issuedAt: DateTime.now(),
      scanFindings: [
        '✅  $total questions detected — matches expected count',
        '✅  No duplicate questions detected',
        '✅  All questions have exactly 4 options',
        '✅  Topic distribution within acceptable range',
        '✅  Difficulty balance: ${diff[QuestionDifficulty.easy] ?? 0}E / ${diff[QuestionDifficulty.medium] ?? 0}M / ${diff[QuestionDifficulty.hard] ?? 0}H',
        '✅  Print layout validated — margins and font sizes compliant',
        '✅  No PII or answer keys detected in paper body',
        '✅  Watermark integrity verified',
      ],
    );
  }
}
