import 'dart:convert';
import 'dart:math';
import 'dart:typed_data';
import 'package:crypto/crypto.dart';
import 'package:cryptography/cryptography.dart';
import '../models/question.dart';

/// Encrypted payload stored per question
class EncryptedPayload {
  final String ciphertext; // base64
  final String nonce;      // base64
  final String mac;        // base64
  final String wrappedKey; // base64 — AES key XOR'd with setter private key

  const EncryptedPayload({
    required this.ciphertext,
    required this.nonce,
    required this.mac,
    required this.wrappedKey,
  });
}

class CryptoService {
  static final _aesGcm = AesGcm.with256bits();
  static final _rng = Random.secure();

  // ── Key operations ─────────────────────────────────────────────────────────

  /// Generate random 32-byte "private key" bytes for a setter
  static List<int> generatePrivateKey() =>
      List.generate(32, (_) => _rng.nextInt(256));

  /// Derive "public key" = SHA-256 of private key (simulated RSA public key)
  static List<int> derivePublicKey(List<int> privateKey) =>
      sha256.convert(privateKey).bytes;

  /// Returns a colon-separated hex fingerprint of the first 16 bytes
  static String keyFingerprint(List<int> publicKeyBytes) {
    final hex = publicKeyBytes
        .take(16)
        .map((b) => b.toRadixString(16).padLeft(2, '0'))
        .toList();
    // Group as XX:XX:XX...
    final pairs = <String>[];
    for (var i = 0; i < hex.length; i += 2) {
      pairs.add('${hex[i]}${hex[i + 1]}');
    }
    return pairs.join(':').toUpperCase();
  }

  // ── Encryption ─────────────────────────────────────────────────────────────

  /// Encrypt a raw question JSON using AES-256-GCM.
  /// The AES key is "wrapped" (XOR'd with setter private key — simulates RSA-OAEP wrapping).
  static Future<EncryptedPayload> encryptQuestion(
    RawQuestion question,
    List<int> setterPrivateKey,
  ) async {
    // 1. Serialize question to JSON bytes
    final plaintext = Uint8List.fromList(
      utf8.encode(jsonEncode(question.toJson())),
    );

    // 2. Generate a fresh random AES-256 secret key
    final secretKey = await _aesGcm.newSecretKey();
    final keyBytes = await secretKey.extractBytes();

    // 3. Generate random 12-byte nonce for GCM
    final nonce = _aesGcm.newNonce();

    // 4. AES-256-GCM encrypt
    final box = await _aesGcm.encrypt(
      plaintext,
      secretKey: secretKey,
      nonce: nonce,
    );

    // 5. Wrap the AES key by XOR-ing with setter private key (simulated RSA-OAEP)
    final wrappedKey = List.generate(
      keyBytes.length,
      (i) => keyBytes[i] ^ setterPrivateKey[i % setterPrivateKey.length],
    );

    return EncryptedPayload(
      ciphertext: base64Encode(box.cipherText),
      nonce:      base64Encode(box.nonce),
      mac:        base64Encode(box.mac.bytes),
      wrappedKey: base64Encode(wrappedKey),
    );
  }

  // ── Decryption ─────────────────────────────────────────────────────────────

  /// Decrypt an encrypted question blob using the setter's private key.
  static Future<Map<String, dynamic>> decryptQuestion(
    EncryptedPayload payload,
    List<int> setterPrivateKey,
  ) async {
    // 1. Unwrap the AES key
    final wrappedKeyBytes = base64Decode(payload.wrappedKey);
    final keyBytes = List.generate(
      wrappedKeyBytes.length,
      (i) => wrappedKeyBytes[i] ^ setterPrivateKey[i % setterPrivateKey.length],
    );

    // 2. Reconstruct SecretBox
    final secretKey = SecretKey(keyBytes);
    final box = SecretBox(
      base64Decode(payload.ciphertext),
      nonce: base64Decode(payload.nonce),
      mac:   Mac(base64Decode(payload.mac)),
    );

    // 3. Decrypt
    final plainBytes = await _aesGcm.decrypt(box, secretKey: secretKey);

    // 4. Deserialize JSON
    return jsonDecode(utf8.decode(plainBytes)) as Map<String, dynamic>;
  }

  // ── Paper seed ─────────────────────────────────────────────────────────────

  /// Derive paper seed by XOR-ing SHA-256 of each setter's public key.
  /// Verifiable: anyone with public keys can reproduce the same seed.
  static String generatePaperSeed(List<List<int>> setterPublicKeys) {
    final result = List<int>.filled(32, 0);
    for (final publicKey in setterPublicKeys) {
      final hash = sha256.convert(publicKey).bytes;
      for (var i = 0; i < 32; i++) {
        result[i] ^= hash[i];
      }
    }
    return result.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
  }

  /// Derive an alternate seed for backup paper (rotate + XOR with a salt)
  static String generateBackupSeed(String primarySeed, String salt) {
    final seedBytes = List.generate(
      32,
      (i) => int.parse(primarySeed.substring(i * 2, i * 2 + 2), radix: 16),
    );
    final saltHash = sha256.convert(utf8.encode(salt)).bytes;
    final backupBytes = List.generate(
      32,
      (i) => (seedBytes[(i + 1) % 32] ^ saltHash[i]) & 0xFF,
    );
    return backupBytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
  }

  // ── Signing ────────────────────────────────────────────────────────────────

  /// Compute SHA-256 hash of assembled paper content (simulates admin digital signature)
  static String hashPaperContent(String content) =>
      sha256.convert(utf8.encode(content)).toString();

  // ── Display helpers ────────────────────────────────────────────────────────

  /// Format a hex string with spaces every 4 chars for readability
  static String formatHex(String hex, {int groupSize = 8}) {
    final buffer = StringBuffer();
    for (var i = 0; i < hex.length; i++) {
      if (i > 0 && i % groupSize == 0) buffer.write(' ');
      buffer.write(hex[i]);
    }
    return buffer.toString().toUpperCase();
  }

  /// Truncate ciphertext for display
  static String ciphertextPreview(String base64Cipher) {
    final raw = base64Cipher.replaceAll(RegExp(r'[^A-Za-z0-9]'), '');
    return raw.length > 48 ? '${raw.substring(0, 48)}...' : raw;
  }
}
