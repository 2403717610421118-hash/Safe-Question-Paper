import 'dart:math';
import 'dart:convert';
import '../models/question.dart';
import '../models/exam_paper.dart';
import 'crypto_service.dart';

class PaperGeneratorService {
  /// Assembles a final paper from a pool of encrypted questions.
  ///
  /// Steps:
  ///  1. Derive seed from setter public keys (XOR of SHA-256)
  ///  2. Shuffle question indices using seeded Random
  ///  3. Pick the first [count] questions
  ///  4. Compute admin signature (SHA-256 of paper content JSON)
  static List<int> shuffleIndices(String hexSeed, int poolSize) {
    // Convert first 8 bytes of seed to int64 for seeding Dart's Random
    final seedInt = _seedToInt(hexSeed);
    final rng = Random(seedInt);

    final indices = List.generate(poolSize, (i) => i);
    // Fisher–Yates shuffle with seeded RNG
    for (var i = poolSize - 1; i > 0; i--) {
      final j = rng.nextInt(i + 1);
      final tmp = indices[i];
      indices[i] = indices[j];
      indices[j] = tmp;
    }
    return indices;
  }

  static int _seedToInt(String hexSeed) {
    // Take first 8 bytes (16 hex chars) → interpret as big-endian int
    final seedBytes = List.generate(
      8,
      (i) => int.parse(hexSeed.substring(i * 2, i * 2 + 2), radix: 16),
    );
    int value = 0;
    for (final b in seedBytes) {
      value = (value << 8) | b;
    }
    return value;
  }

  /// Build an ExamPaper from raw (decrypted) questions using the given seed.
  static ExamPaper buildPaper({
    required String paperId,
    required String title,
    required String subjectCode,
    required String subjectName,
    required List<PaperQuestion> allPaperQuestions,
    required String hexSeed,
    required List<String> setterFingerprints,
    required int questionCount,
    bool isBackup = false,
    String? backupSalt,
  }) {
    // Shuffle and pick
    final shuffled = shuffleIndices(hexSeed, allPaperQuestions.length);
    final selected = shuffled
        .take(questionCount)
        .map((i) => allPaperQuestions[i])
        .toList();

    // Re-number questions 1..N
    final numbered = selected
        .asMap()
        .entries
        .map((e) => PaperQuestion(
              questionNumber: e.key + 1,
              topic: e.value.topic,
              text: e.value.text,
              options: e.value.options,
              difficulty: e.value.difficulty,
              subjectCode: e.value.subjectCode,
            ))
        .toList();

    // Admin signature: SHA-256 of serialized paper
    final paperJson = jsonEncode({
      'id': paperId,
      'seed': hexSeed,
      'questions': numbered
          .map((q) => {
                'number': q.questionNumber,
                'text': q.text,
                'options': q.options,
              })
          .toList(),
    });
    final signature = CryptoService.hashPaperContent(paperJson);

    final now = DateTime.now();
    return ExamPaper(
      id: paperId,
      title: title,
      subjectCode: subjectCode,
      subjectName: subjectName,
      questions: numbered,
      seed: hexSeed,
      adminSignature: signature,
      status: PaperStatus.draft,
      setterFingerprints: setterFingerprints,
      chainOfCustody: [
        CustodyEntry(
          action: 'Paper Generated',
          actorName: 'Admin System',
          actorRole: 'admin',
          timestamp: now,
          details: 'Seed: ${hexSeed.substring(0, 16).toUpperCase()}... | '
              '${numbered.length} questions assembled',
        ),
      ],
      generatedAt: now,
      isBackup: isBackup,
      backupSalt: backupSalt,
    );
  }

  /// Convert a list of [RawQuestion] to [PaperQuestion] (strips answers)
  static List<PaperQuestion> toPaperQuestions(List<RawQuestion> raws) =>
      raws
          .map((q) => PaperQuestion(
                questionNumber: 0, // will be assigned during buildPaper
                topic: q.topic,
                text: q.text,
                options: q.options,
                difficulty: q.difficulty,
                subjectCode: q.subjectCode,
              ))
          .toList();
}
