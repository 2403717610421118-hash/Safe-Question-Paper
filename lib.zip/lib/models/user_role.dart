enum UserRole { setter, admin, printOfficer }

extension UserRoleExt on UserRole {
  String get displayName {
    switch (this) {
      case UserRole.setter:
        return 'Question Setter';
      case UserRole.admin:
        return 'Admin / Controller';
      case UserRole.printOfficer:
        return 'Print Center Officer';
    }
  }

  String get shortName {
    switch (this) {
      case UserRole.setter:
        return 'Setter';
      case UserRole.admin:
        return 'Admin';
      case UserRole.printOfficer:
        return 'Print Officer';
    }
  }

  String get description {
    switch (this) {
      case UserRole.setter:
        return 'Submit and encrypt exam questions securely';
      case UserRole.admin:
        return 'Oversee the full pipeline, generate and seal papers';
      case UserRole.printOfficer:
        return 'Authenticate and unlock sealed papers for printing';
    }
  }

  String get icon {
    switch (this) {
      case UserRole.setter:
        return '✍️';
      case UserRole.admin:
        return '🛡️';
      case UserRole.printOfficer:
        return '🖨️';
    }
  }
}
