import 'question.dart';

enum PaperStatus { draft, sealed, dispatched, printed }

extension PaperStatusExt on PaperStatus {
  String get label {
    switch (this) {
      case PaperStatus.draft:      return 'Draft';
      case PaperStatus.sealed:     return 'Sealed';
      case PaperStatus.dispatched: return 'Dispatched';
      case PaperStatus.printed:    return 'Printed';
    }
  }

  bool get isLocked => this != PaperStatus.draft;
}

class CustodyEntry {
  final String action;
  final String actorName;
  final String actorRole;
  final DateTime timestamp;
  final String details;

  const CustodyEntry({
    required this.action,
    required this.actorName,
    required this.actorRole,
    required this.timestamp,
    required this.details,
  });
}

class ExamPaper {
  final String id;
  final String title;
  final String subjectCode;
  final String subjectName;
  final List<PaperQuestion> questions;
  final String seed;                     // hex seed used for shuffling
  final String adminSignature;           // SHA-256 of paper content
  final PaperStatus status;
  final List<String> setterFingerprints; // fingerprints that contributed to seed
  final List<CustodyEntry> chainOfCustody;
  final DateTime generatedAt;
  final bool isBackup;
  final String? backupSalt;              // extra salt used if backup

  const ExamPaper({
    required this.id,
    required this.title,
    required this.subjectCode,
    required this.subjectName,
    required this.questions,
    required this.seed,
    required this.adminSignature,
    required this.status,
    required this.setterFingerprints,
    required this.chainOfCustody,
    required this.generatedAt,
    this.isBackup = false,
    this.backupSalt,
  });

  ExamPaper copyWith({
    PaperStatus? status,
    List<CustodyEntry>? chainOfCustody,
  }) =>
      ExamPaper(
        id: id,
        title: title,
        subjectCode: subjectCode,
        subjectName: subjectName,
        questions: questions,
        seed: seed,
        adminSignature: adminSignature,
        status: status ?? this.status,
        setterFingerprints: setterFingerprints,
        chainOfCustody: chainOfCustody ?? this.chainOfCustody,
        generatedAt: generatedAt,
        isBackup: isBackup,
        backupSalt: backupSalt,
      );

  /// Difficulty distribution map
  Map<QuestionDifficulty, int> get difficultyBreakdown {
    final map = <QuestionDifficulty, int>{};
    for (final q in questions) {
      map[q.difficulty] = (map[q.difficulty] ?? 0) + 1;
    }
    return map;
  }

  /// Topic distribution map
  Map<String, int> get topicBreakdown {
    final map = <String, int>{};
    for (final q in questions) {
      map[q.topic] = (map[q.topic] ?? 0) + 1;
    }
    return map;
  }
}
