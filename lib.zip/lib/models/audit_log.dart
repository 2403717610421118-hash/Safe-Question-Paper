class AuditLog {
  final String id;
  final String action;
  final String actorId;
  final String actorName;
  final String actorRole;
  final DateTime timestamp;
  final Map<String, String> metadata;
  final AuditSeverity severity;

  const AuditLog({
    required this.id,
    required this.action,
    required this.actorId,
    required this.actorName,
    required this.actorRole,
    required this.timestamp,
    this.metadata = const {},
    this.severity = AuditSeverity.info,
  });
}

enum AuditSeverity { info, success, warning, critical }

extension AuditSeverityExt on AuditSeverity {
  String get label {
    switch (this) {
      case AuditSeverity.info:     return 'INFO';
      case AuditSeverity.success:  return 'SUCCESS';
      case AuditSeverity.warning:  return 'WARNING';
      case AuditSeverity.critical: return 'CRITICAL';
    }
  }
}

/// Well-known audit action constants
class AuditActions {
  static const String setterLogin        = 'SETTER_LOGIN';
  static const String adminLogin         = 'ADMIN_LOGIN';
  static const String printOfficerLogin  = 'PRINT_OFFICER_LOGIN';
  static const String questionSubmitted  = 'QUESTION_SUBMITTED';
  static const String questionEncrypted  = 'QUESTION_ENCRYPTED';
  static const String sampleQuestionsLoaded = 'SAMPLE_QUESTIONS_LOADED';
  static const String paperGenerationStarted = 'PAPER_GENERATION_STARTED';
  static const String paperGenerated     = 'PAPER_GENERATED';
  static const String paperSealed        = 'PAPER_SEALED';
  static const String paperDispatched    = 'PAPER_DISPATCHED';
  static const String ocrScanStarted     = 'OCR_SCAN_STARTED';
  static const String ocrScanComplete    = 'OCR_SCAN_COMPLETE';
  static const String biometricVerified  = 'BIOMETRIC_VERIFIED';
  static const String printCenterUnlock  = 'PRINT_CENTER_UNLOCK';
  static const String paperDecrypted     = 'PAPER_DECRYPTED';
  static const String paperPrinted       = 'PAPER_PRINTED';
  static const String backupGenerated    = 'BACKUP_PAPER_GENERATED';
  static const String backupSealed       = 'BACKUP_PAPER_SEALED';
}
