enum QuestionDifficulty { easy, medium, hard }

extension QuestionDifficultyExt on QuestionDifficulty {
  String get label {
    switch (this) {
      case QuestionDifficulty.easy:   return 'Easy';
      case QuestionDifficulty.medium: return 'Medium';
      case QuestionDifficulty.hard:   return 'Hard';
    }
  }

  int get weight {
    switch (this) {
      case QuestionDifficulty.easy:   return 1;
      case QuestionDifficulty.medium: return 2;
      case QuestionDifficulty.hard:   return 3;
    }
  }
}

/// A raw (plaintext) question as submitted by a setter
class RawQuestion {
  final String id;
  final String subjectCode;
  final String subjectName;
  final String topic;
  final String text;
  final List<String> options;         // exactly 4 options
  final int correctAnswerIndex;        // 0-3
  final QuestionDifficulty difficulty;
  final String setterId;
  final String setterName;

  const RawQuestion({
    required this.id,
    required this.subjectCode,
    required this.subjectName,
    required this.topic,
    required this.text,
    required this.options,
    required this.correctAnswerIndex,
    required this.difficulty,
    required this.setterId,
    required this.setterName,
  });

  Map<String, dynamic> toJson() => {
    'id': id,
    'subjectCode': subjectCode,
    'subjectName': subjectName,
    'topic': topic,
    'text': text,
    'options': options,
    'correctAnswerIndex': correctAnswerIndex,
    'difficulty': difficulty.name,
    'setterId': setterId,
    'setterName': setterName,
  };
}

/// An encrypted question blob stored after setter submission
class EncryptedQuestion {
  final String id;
  final String setterId;
  final String setterName;
  final String subjectCode;
  final String subjectName;
  final String topic;
  final QuestionDifficulty difficulty;
  final String setterKeyFingerprint;
  final DateTime submittedAt;

  // AES-256-GCM encrypted fields
  final String ciphertext;   // base64 encrypted JSON of RawQuestion
  final String nonce;        // base64 nonce
  final String mac;          // base64 authentication tag
  final String wrappedKey;   // base64 AES key XOR'd with setter private key

  const EncryptedQuestion({
    required this.id,
    required this.setterId,
    required this.setterName,
    required this.subjectCode,
    required this.subjectName,
    required this.topic,
    required this.difficulty,
    required this.setterKeyFingerprint,
    required this.submittedAt,
    required this.ciphertext,
    required this.nonce,
    required this.mac,
    required this.wrappedKey,
  });

  /// First 32 chars of ciphertext for display as "encrypted preview"
  String get ciphertextPreview => ciphertext.length > 32
      ? ciphertext.substring(0, 32)
      : ciphertext;
}

/// A decrypted question assembled into a final paper
class PaperQuestion {
  final int questionNumber;
  final String topic;
  final String text;
  final List<String> options;
  final QuestionDifficulty difficulty;
  final String subjectCode;

  const PaperQuestion({
    required this.questionNumber,
    required this.topic,
    required this.text,
    required this.options,
    required this.difficulty,
    required this.subjectCode,
  });
}
