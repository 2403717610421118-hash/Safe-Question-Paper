class SetterProfile {
  final String id;
  final String name;
  final String subjectCode;
  final String subjectName;
  final List<int> privateKeyBytes; // 32 simulated RSA-private key bytes
  final List<int> publicKeyBytes;  // SHA-256 of private key (simulated RSA-public)
  final String fingerprint;        // colon-separated hex of first 16 bytes

  const SetterProfile({
    required this.id,
    required this.name,
    required this.subjectCode,
    required this.subjectName,
    required this.privateKeyBytes,
    required this.publicKeyBytes,
    required this.fingerprint,
  });

  /// Full public key as lowercase hex string
  String get publicKeyHex =>
      publicKeyBytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();

  /// Private key display (first 8 bytes only, for security UX)
  String get privateKeyPreview =>
      privateKeyBytes
          .take(8)
          .map((b) => b.toRadixString(16).padLeft(2, '0'))
          .join()
          .toUpperCase() +
      '...';
}
