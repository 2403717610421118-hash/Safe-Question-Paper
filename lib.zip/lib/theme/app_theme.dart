import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppTheme {
  // ── Core palette ──────────────────────────────────────────────────────────
  static const Color background    = Color(0xFF080E1A);
  static const Color surface       = Color(0xFF0D1B2E);
  static const Color panel         = Color(0xFF1A2744);
  static const Color panelLight    = Color(0xFF243356);
  static const Color border        = Color(0xFF2A3F66);
  static const Color borderGlow    = Color(0xFF1E5FCC);

  static const Color accent        = Color(0xFF00BFFF);   // electric cyan
  static const Color accentDark    = Color(0xFF0080CC);
  static const Color accentGlow    = Color(0x4400BFFF);

  static const Color secure        = Color(0xFF00E676);   // emerald green
  static const Color secureGlow    = Color(0x4400E676);

  static const Color warning       = Color(0xFFFFD600);
  static const Color warningGlow   = Color(0x44FFD600);

  static const Color danger        = Color(0xFFFF5252);
  static const Color dangerGlow    = Color(0x44FF5252);

  static const Color textPrimary   = Color(0xFFE8F4FD);
  static const Color textSecondary = Color(0xFF7FA8C9);
  static const Color textMuted     = Color(0xFF3F6080);
  static const Color textInverse   = Color(0xFF080E1A);

  // ── Gradients ─────────────────────────────────────────────────────────────
  static const LinearGradient accentGradient = LinearGradient(
    colors: [Color(0xFF00BFFF), Color(0xFF0060FF)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient secureGradient = LinearGradient(
    colors: [Color(0xFF00E676), Color(0xFF00BCD4)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient panelGradient = LinearGradient(
    colors: [Color(0xFF1A2744), Color(0xFF0D1B2E)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  static const LinearGradient backgroundGradient = LinearGradient(
    colors: [Color(0xFF080E1A), Color(0xFF0A1628), Color(0xFF08101E)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // ── Typography ────────────────────────────────────────────────────────────
  static TextTheme get textTheme => GoogleFonts.interTextTheme().copyWith(
    displayLarge:  GoogleFonts.inter(color: textPrimary,   fontSize: 56, fontWeight: FontWeight.w800),
    displayMedium: GoogleFonts.inter(color: textPrimary,   fontSize: 40, fontWeight: FontWeight.w700),
    displaySmall:  GoogleFonts.inter(color: textPrimary,   fontSize: 32, fontWeight: FontWeight.w700),
    headlineLarge: GoogleFonts.inter(color: textPrimary,   fontSize: 28, fontWeight: FontWeight.w700),
    headlineMedium:GoogleFonts.inter(color: textPrimary,   fontSize: 22, fontWeight: FontWeight.w600),
    headlineSmall: GoogleFonts.inter(color: textPrimary,   fontSize: 18, fontWeight: FontWeight.w600),
    titleLarge:    GoogleFonts.inter(color: textPrimary,   fontSize: 16, fontWeight: FontWeight.w600),
    titleMedium:   GoogleFonts.inter(color: textSecondary, fontSize: 14, fontWeight: FontWeight.w500),
    titleSmall:    GoogleFonts.inter(color: textSecondary, fontSize: 12, fontWeight: FontWeight.w500),
    bodyLarge:     GoogleFonts.inter(color: textPrimary,   fontSize: 16),
    bodyMedium:    GoogleFonts.inter(color: textSecondary, fontSize: 14),
    bodySmall:     GoogleFonts.inter(color: textMuted,     fontSize: 12),
    labelLarge:    GoogleFonts.inter(color: textPrimary,   fontSize: 14, fontWeight: FontWeight.w600),
    labelMedium:   GoogleFonts.inter(color: textSecondary, fontSize: 12, fontWeight: FontWeight.w500),
    labelSmall:    GoogleFonts.inter(color: textMuted,     fontSize: 11, fontWeight: FontWeight.w500),
  );

  /// Monospace font for crypto hashes, keys, ciphertext blobs
  static TextStyle monoStyle({
    double fontSize = 12,
    Color color = textSecondary,
    FontWeight fontWeight = FontWeight.w400,
  }) =>
      GoogleFonts.jetBrainsMono(
        fontSize: fontSize,
        color: color,
        fontWeight: fontWeight,
      );

  // ── Theme data ─────────────────────────────────────────────────────────────
  static ThemeData get dark => ThemeData(
    useMaterial3: true,
    brightness: Brightness.dark,
    scaffoldBackgroundColor: background,
    colorScheme: const ColorScheme.dark(
      primary: accent,
      onPrimary: textInverse,
      secondary: secure,
      onSecondary: textInverse,
      error: danger,
      onError: textInverse,
      surface: surface,
      onSurface: textPrimary,
    ),
    textTheme: textTheme,
    cardTheme: CardThemeData(
      color: panel,
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: const BorderSide(color: border, width: 1),
      ),
    ),
    inputDecorationTheme: InputDecorationTheme(
      filled: true,
      fillColor: surface,
      border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: border),
      ),
      enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: border),
      ),
      focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(12),
        borderSide: const BorderSide(color: accent, width: 2),
      ),
      labelStyle: GoogleFonts.inter(color: textSecondary),
      hintStyle: GoogleFonts.inter(color: textMuted),
    ),
    elevatedButtonTheme: ElevatedButtonThemeData(
      style: ElevatedButton.styleFrom(
        backgroundColor: accent,
        foregroundColor: textInverse,
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        textStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600),
        elevation: 0,
      ),
    ),
    outlinedButtonTheme: OutlinedButtonThemeData(
      style: OutlinedButton.styleFrom(
        foregroundColor: accent,
        side: const BorderSide(color: accent),
        padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 14),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        textStyle: GoogleFonts.inter(fontSize: 14, fontWeight: FontWeight.w600),
      ),
    ),
    dividerTheme: const DividerThemeData(color: border, thickness: 1),
    iconTheme: const IconThemeData(color: textSecondary),
    appBarTheme: AppBarTheme(
      backgroundColor: surface,
      foregroundColor: textPrimary,
      elevation: 0,
      surfaceTintColor: Colors.transparent,
      titleTextStyle: GoogleFonts.inter(
        color: textPrimary,
        fontSize: 18,
        fontWeight: FontWeight.w600,
      ),
    ),
  );
}
