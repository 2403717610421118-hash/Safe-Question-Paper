import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/auth_provider.dart';
import '../providers/question_provider.dart';
import '../models/user_role.dart';
import '../theme/app_theme.dart';

/// Top status bar shown across all authenticated pages
class SecurityStatusBar extends StatefulWidget {
  const SecurityStatusBar({super.key});

  @override
  State<SecurityStatusBar> createState() => _SecurityStatusBarState();
}

class _SecurityStatusBarState extends State<SecurityStatusBar>
    with SingleTickerProviderStateMixin {
  late AnimationController _pulseController;
  late Animation<double> _pulse;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
    _pulse = CurvedAnimation(parent: _pulseController, curve: Curves.easeInOut);
  }

  @override
  void dispose() {
    _pulseController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final questions = context.watch<QuestionProvider>();

    return Container(
      height: 40,
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(bottom: BorderSide(color: AppTheme.border)),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          // Secure indicator
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, __) => Container(
              width: 8,
              height: 8,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: AppTheme.secure,
                boxShadow: [
                  BoxShadow(
                    color: AppTheme.secure.withOpacity(0.3 + _pulse.value * 0.4),
                    blurRadius: 6 + _pulse.value * 4,
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(width: 8),
          Text(
            'SYSTEM SECURE',
            style: AppTheme.monoStyle(
              fontSize: 9,
              color: AppTheme.secure,
              fontWeight: FontWeight.w700,
            ),
          ),
          _divider(),
          _statusChip(
            icon: Icons.lock,
            label: 'AES-256-GCM',
            color: AppTheme.accent,
          ),
          _divider(),
          _statusChip(
            icon: Icons.fingerprint,
            label: 'BIOMETRIC: ${auth.biometricVerified ? 'ACTIVE' : 'PENDING'}',
            color: auth.biometricVerified ? AppTheme.secure : AppTheme.warning,
          ),
          _divider(),
          _statusChip(
            icon: Icons.question_mark_rounded,
            label: '${questions.totalCount} QUESTIONS ENCRYPTED',
            color: AppTheme.textSecondary,
          ),
          const Spacer(),
          // Role badge
          if (auth.currentRole != null) ...[
            _roleChip(auth.currentRole!),
            const SizedBox(width: 12),
          ],
          // Time
          StreamBuilder(
            stream: Stream.periodic(const Duration(seconds: 1)),
            builder: (context, _) {
              final now = DateTime.now();
              final h = now.hour.toString().padLeft(2, '0');
              final m = now.minute.toString().padLeft(2, '0');
              final s = now.second.toString().padLeft(2, '0');
              return Text(
                '$h:$m:$s',
                style: AppTheme.monoStyle(
                  fontSize: 11,
                  color: AppTheme.textMuted,
                ),
              );
            },
          ),
        ],
      ),
    );
  }

  Widget _divider() => Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: Container(width: 1, height: 16, color: AppTheme.border),
      );

  Widget _statusChip({
    required IconData icon,
    required String label,
    required Color color,
  }) =>
      Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 10, color: color),
          const SizedBox(width: 4),
          Text(
            label,
            style: AppTheme.monoStyle(
              fontSize: 9,
              color: color,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      );

  Widget _roleChip(UserRole role) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
        decoration: BoxDecoration(
          color: AppTheme.accentGlow,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppTheme.accent.withOpacity(0.4)),
        ),
        child: Text(
          role.shortName.toUpperCase(),
          style: AppTheme.monoStyle(
            fontSize: 9,
            color: AppTheme.accent,
            fontWeight: FontWeight.w700,
          ),
        ),
      );
}
