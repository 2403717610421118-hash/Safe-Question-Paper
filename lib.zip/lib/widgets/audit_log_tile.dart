import 'package:flutter/material.dart';
import '../models/audit_log.dart';
import '../theme/app_theme.dart';

class AuditLogTile extends StatelessWidget {
  final AuditLog log;
  final bool isFirst;

  const AuditLogTile({
    super.key,
    required this.log,
    this.isFirst = false,
  });

  @override
  Widget build(BuildContext context) {
    final color = _severityColor(log.severity);

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Timeline spine
          SizedBox(
            width: 24,
            child: Column(
              children: [
                // Dot
                Container(
                  width: 10,
                  height: 10,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: color,
                    boxShadow: [BoxShadow(color: color.withOpacity(0.4), blurRadius: 6)],
                  ),
                ),
                // Vertical line
                Expanded(
                  child: Container(width: 1, color: AppTheme.border),
                ),
              ],
            ),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 6,
                          vertical: 2,
                        ),
                        decoration: BoxDecoration(
                          color: color.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(4),
                          border: Border.all(color: color.withOpacity(0.4)),
                        ),
                        child: Text(
                          log.severity.label,
                          style: AppTheme.monoStyle(
                            fontSize: 8,
                            color: color,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        _formatTimestamp(log.timestamp),
                        style: AppTheme.monoStyle(
                          fontSize: 9,
                          color: AppTheme.textMuted,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  Text(
                    log.action.replaceAll('_', ' '),
                    style: Theme.of(context)
                        .textTheme
                        .labelLarge
                        ?.copyWith(color: AppTheme.textPrimary),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${log.actorName} • ${log.actorRole}',
                    style: Theme.of(context).textTheme.labelSmall,
                  ),
                  if (log.metadata.isNotEmpty) ...[
                    const SizedBox(height: 4),
                    ...log.metadata.entries.map(
                      (e) => Text(
                        '${e.key}: ${e.value}',
                        style: AppTheme.monoStyle(
                          fontSize: 9,
                          color: AppTheme.textMuted,
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Color _severityColor(AuditSeverity s) {
    switch (s) {
      case AuditSeverity.info:     return AppTheme.accent;
      case AuditSeverity.success:  return AppTheme.secure;
      case AuditSeverity.warning:  return AppTheme.warning;
      case AuditSeverity.critical: return AppTheme.danger;
    }
  }

  String _formatTimestamp(DateTime dt) {
    final h = dt.hour.toString().padLeft(2, '0');
    final m = dt.minute.toString().padLeft(2, '0');
    final s = dt.second.toString().padLeft(2, '0');
    return '$h:$m:$s';
  }
}
