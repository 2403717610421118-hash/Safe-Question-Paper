import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../models/user_role.dart';
import '../models/exam_paper.dart';
import '../providers/auth_provider.dart';
import '../providers/paper_provider.dart';
import '../theme/app_theme.dart';

class _NavItem {
  final String label;
  final IconData icon;
  final String route;
  final List<UserRole> allowedRoles;

  const _NavItem({
    required this.label,
    required this.icon,
    required this.route,
    required this.allowedRoles,
  });
}

const _navItems = [
  _NavItem(
    label: 'My Questions',
    icon: Icons.edit_note_rounded,
    route: '/setter',
    allowedRoles: [UserRole.setter],
  ),
  _NavItem(
    label: 'Dashboard',
    icon: Icons.dashboard_rounded,
    route: '/admin',
    allowedRoles: [UserRole.admin],
  ),
  _NavItem(
    label: 'Generate Paper',
    icon: Icons.shuffle_rounded,
    route: '/admin/generate',
    allowedRoles: [UserRole.admin],
  ),
  _NavItem(
    label: 'Security Monitor',
    icon: Icons.monitor_heart_rounded,
    route: '/admin/security',
    allowedRoles: [UserRole.admin],
  ),
  _NavItem(
    label: 'Backup Paper',
    icon: Icons.copy_all_rounded,
    route: '/admin/backup',
    allowedRoles: [UserRole.admin],
  ),
  _NavItem(
    label: 'Secure Inbox',
    icon: Icons.inbox_rounded,
    route: '/print',
    allowedRoles: [UserRole.printOfficer],
  ),
];

class AppSidebar extends StatelessWidget {
  final String currentRoute;

  const AppSidebar({super.key, required this.currentRoute});

  @override
  Widget build(BuildContext context) {
    final auth = context.watch<AuthProvider>();
    final paper = context.watch<PaperProvider>();
    final role = auth.currentRole;
    if (role == null) return const SizedBox.shrink();

    final items = _navItems.where((n) => n.allowedRoles.contains(role)).toList();

    return Container(
      width: 220,
      decoration: const BoxDecoration(
        color: AppTheme.surface,
        border: Border(right: BorderSide(color: AppTheme.border)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Branding
          Container(
            padding: const EdgeInsets.all(20),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        gradient: AppTheme.accentGradient,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: const Icon(Icons.lock, size: 18, color: Colors.white),
                    ),
                    const SizedBox(width: 10),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'SecureExam',
                          style: Theme.of(context)
                              .textTheme
                              .titleLarge
                              ?.copyWith(color: AppTheme.textPrimary),
                        ),
                        Text(
                          'v1.0 — DEMO',
                          style: AppTheme.monoStyle(
                            fontSize: 8,
                            color: AppTheme.textMuted,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                // Role pill
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    color: AppTheme.accentGlow,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: AppTheme.accent.withOpacity(0.3)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text(
                        role.icon,
                        style: const TextStyle(fontSize: 12),
                      ),
                      const SizedBox(width: 6),
                      Flexible(
                        child: Text(
                          role.displayName,
                          style: AppTheme.monoStyle(
                            fontSize: 9,
                            color: AppTheme.accent,
                            fontWeight: FontWeight.w700,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                ),
                if (auth.currentSetterProfile != null) ...[
                  const SizedBox(height: 6),
                  Text(
                    auth.currentSetterProfile!.name,
                    style: Theme.of(context).textTheme.labelSmall,
                    overflow: TextOverflow.ellipsis,
                  ),
                  Text(
                    auth.currentSetterProfile!.subjectName,
                    style: AppTheme.monoStyle(
                      fontSize: 9,
                      color: AppTheme.accent,
                    ),
                  ),
                ],
              ],
            ),
          ),
          const Divider(height: 1, color: AppTheme.border),
          const SizedBox(height: 8),
          // Nav items
          ...items.map((item) => _NavTile(
                item: item,
                isActive: currentRoute == item.route,
              )),
          // Paper status indicator (admin only)
          if (role == UserRole.admin && paper.hasPaper) ...[
            const Spacer(),
            const Divider(height: 1, color: AppTheme.border),
            _PaperStatusWidget(paper: paper),
          ] else
            const Spacer(),
          const Divider(height: 1, color: AppTheme.border),
          // Logout
          _logoutTile(context, auth),
          const SizedBox(height: 8),
        ],
      ),
    );
  }

  Widget _logoutTile(BuildContext context, AuthProvider auth) {
    return ListTile(
      dense: true,
      leading: const Icon(Icons.logout_rounded, size: 18, color: AppTheme.textMuted),
      title: Text(
        'Switch Role',
        style: Theme.of(context).textTheme.labelMedium,
      ),
      onTap: () {
        auth.logout();
        context.go('/role-select');
      },
    );
  }
}

class _NavTile extends StatelessWidget {
  final _NavItem item;
  final bool isActive;

  const _NavTile({required this.item, required this.isActive});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: isActive ? AppTheme.accentGlow : Colors.transparent,
        borderRadius: BorderRadius.circular(8),
        border: isActive
            ? Border.all(color: AppTheme.accent.withOpacity(0.3))
            : null,
      ),
      child: ListTile(
        dense: true,
        leading: Icon(
          item.icon,
          size: 18,
          color: isActive ? AppTheme.accent : AppTheme.textMuted,
        ),
        title: Text(
          item.label,
          style: Theme.of(context).textTheme.labelMedium?.copyWith(
                color: isActive ? AppTheme.accent : AppTheme.textSecondary,
                fontWeight: isActive ? FontWeight.w600 : FontWeight.w400,
              ),
        ),
        onTap: () => context.go(item.route),
      ),
    );
  }
}

class _PaperStatusWidget extends StatelessWidget {
  final PaperProvider paper;

  const _PaperStatusWidget({required this.paper});

  @override
  Widget build(BuildContext context) {
    final p = paper.primaryPaper!;
    final statusColor = _statusColor(p.status);
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'CURRENT PAPER',
            style: AppTheme.monoStyle(
              fontSize: 8,
              color: AppTheme.textMuted,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: statusColor,
                ),
              ),
              const SizedBox(width: 6),
              Text(
                p.status.label.toUpperCase(),
                style: AppTheme.monoStyle(
                  fontSize: 10,
                  color: statusColor,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            '${p.questions.length} questions',
            style: Theme.of(context).textTheme.labelSmall,
          ),
          Text(
            p.id,
            style: AppTheme.monoStyle(fontSize: 8, color: AppTheme.textMuted),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }

  Color _statusColor(dynamic status) {
    switch (status.toString().split('.').last) {
      case 'draft':      return AppTheme.warning;
      case 'sealed':     return AppTheme.accent;
      case 'dispatched': return AppTheme.secure;
      case 'printed':    return AppTheme.textMuted;
      default:           return AppTheme.textMuted;
    }
  }
}
