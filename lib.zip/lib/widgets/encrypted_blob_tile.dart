import 'package:flutter/material.dart';
import '../models/question.dart';
import '../services/crypto_service.dart';
import '../theme/app_theme.dart';

/// Shows an encrypted question as a redacted ciphertext block
class EncryptedBlobTile extends StatefulWidget {
  final EncryptedQuestion question;
  final int index;

  const EncryptedBlobTile({
    super.key,
    required this.question,
    required this.index,
  });

  @override
  State<EncryptedBlobTile> createState() => _EncryptedBlobTileState();
}

class _EncryptedBlobTileState extends State<EncryptedBlobTile>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _fadeIn;
  bool _expanded = false;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 400),
    );
    _fadeIn = CurvedAnimation(parent: _controller, curve: Curves.easeOut);
    _controller.forward();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final q = widget.question;
    final diffColor = _diffColor(q.difficulty);

    return FadeTransition(
      opacity: _fadeIn,
      child: Container(
        margin: const EdgeInsets.only(bottom: 8),
        decoration: BoxDecoration(
          color: AppTheme.panel,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(color: AppTheme.border),
        ),
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            borderRadius: BorderRadius.circular(10),
            onTap: () => setState(() => _expanded = !_expanded),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Header row
                  Row(
                    children: [
                      Container(
                        width: 28,
                        height: 28,
                        decoration: BoxDecoration(
                          color: AppTheme.accentGlow,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Center(
                          child: Text(
                            '${widget.index + 1}',
                            style: AppTheme.monoStyle(
                              fontSize: 11,
                              color: AppTheme.accent,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                      const SizedBox(width: 10),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '${q.subjectCode} • ${q.topic}',
                              style: Theme.of(context)
                                  .textTheme
                                  .labelMedium
                                  ?.copyWith(color: AppTheme.textPrimary),
                            ),
                            Text(
                              q.setterName,
                              style: Theme.of(context).textTheme.labelSmall,
                            ),
                          ],
                        ),
                      ),
                      // Difficulty badge
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: 8,
                          vertical: 3,
                        ),
                        decoration: BoxDecoration(
                          color: diffColor.withOpacity(0.15),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: diffColor.withOpacity(0.4)),
                        ),
                        child: Text(
                          q.difficulty.label.toUpperCase(),
                          style: AppTheme.monoStyle(
                            fontSize: 9,
                            color: diffColor,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      // Lock icon
                      const Icon(Icons.lock, size: 16, color: AppTheme.accent),
                      const SizedBox(width: 4),
                      Icon(
                        _expanded ? Icons.expand_less : Icons.expand_more,
                        size: 16,
                        color: AppTheme.textMuted,
                      ),
                    ],
                  ),
                  if (_expanded) ...[
                    const SizedBox(height: 10),
                    const Divider(color: AppTheme.border, height: 1),
                    const SizedBox(height: 10),
                    // Ciphertext preview
                    _ciphertextBlock(q),
                    const SizedBox(height: 8),
                    // Fingerprint
                    Row(
                      children: [
                        Text(
                          'SETTER FP: ',
                          style: AppTheme.monoStyle(
                            fontSize: 9,
                            color: AppTheme.accent,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Flexible(
                          child: Text(
                            q.setterKeyFingerprint,
                            style: AppTheme.monoStyle(
                              fontSize: 9,
                              color: AppTheme.textSecondary,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Text(
                          'SUBMITTED: ',
                          style: AppTheme.monoStyle(
                            fontSize: 9,
                            color: AppTheme.warning,
                            fontWeight: FontWeight.w700,
                          ),
                        ),
                        Text(
                          _formatTime(q.submittedAt),
                          style: AppTheme.monoStyle(
                            fontSize: 9,
                            color: AppTheme.textSecondary,
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Widget _ciphertextBlock(EncryptedQuestion q) {
    final preview = CryptoService.ciphertextPreview(q.ciphertext);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: AppTheme.background,
        borderRadius: BorderRadius.circular(6),
        border: Border.all(color: AppTheme.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'ENCRYPTED PAYLOAD (AES-256-GCM)',
            style: AppTheme.monoStyle(
              fontSize: 8,
              color: AppTheme.accent,
              fontWeight: FontWeight.w700,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            preview,
            style: AppTheme.monoStyle(
              fontSize: 10,
              color: AppTheme.textSecondary,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'NONCE: ${q.nonce.substring(0, 16)}...',
            style: AppTheme.monoStyle(
              fontSize: 9,
              color: AppTheme.textMuted,
            ),
          ),
          Text(
            'MAC:   ${q.mac.substring(0, 16)}...',
            style: AppTheme.monoStyle(
              fontSize: 9,
              color: AppTheme.textMuted,
            ),
          ),
        ],
      ),
    );
  }

  Color _diffColor(QuestionDifficulty d) {
    switch (d) {
      case QuestionDifficulty.easy:   return AppTheme.secure;
      case QuestionDifficulty.medium: return AppTheme.warning;
      case QuestionDifficulty.hard:   return AppTheme.danger;
    }
  }

  String _formatTime(DateTime dt) {
    return '${dt.hour.toString().padLeft(2, '0')}:${dt.minute.toString().padLeft(2, '0')}:${dt.second.toString().padLeft(2, '0')}';
  }
}
