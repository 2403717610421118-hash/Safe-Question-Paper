import 'package:flutter/foundation.dart';
import '../models/audit_log.dart';

class AuditProvider extends ChangeNotifier {
  final List<AuditLog> _logs = [];

  List<AuditLog> get logs => List.unmodifiable(_logs.reversed.toList());

  void log({
    required String action,
    required String actorId,
    required String actorName,
    required String actorRole,
    Map<String, String> metadata = const {},
    AuditSeverity severity = AuditSeverity.info,
  }) {
    _logs.add(AuditLog(
      id: 'LOG-${DateTime.now().millisecondsSinceEpoch}',
      action: action,
      actorId: actorId,
      actorName: actorName,
      actorRole: actorRole,
      timestamp: DateTime.now(),
      metadata: metadata,
      severity: severity,
    ));
    notifyListeners();
  }

  void clear() {
    _logs.clear();
    notifyListeners();
  }
}
