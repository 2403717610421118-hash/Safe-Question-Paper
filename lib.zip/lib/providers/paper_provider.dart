import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../models/exam_paper.dart';
import '../models/question.dart';
import '../services/crypto_service.dart';
import '../services/paper_generator.dart';
import '../services/ocr_simulator.dart';
import '../data/dummy_questions.dart';

enum GenerationStep {
  idle,
  collectingKeys,
  computingSeed,
  shuffling,
  assembling,
  signing,
  done,
}

class PaperProvider extends ChangeNotifier {
  static const int kQuestionsPerPaper = 30;
  final _uuid = const Uuid();

  ExamPaper? _primaryPaper;
  ExamPaper? _backupPaper;
  FairnessReport? _fairnessReport;

  GenerationStep _step = GenerationStep.idle;
  bool _isGenerating = false;
  bool _isSealing = false;
  bool _isRunningOcr = false;
  bool _isUnlocked = false;   // Print center has unlocked
  double _generationProgress = 0.0;
  String _currentSeed = '';
  List<String> _seedComponents = []; // Per-setter XOR contributions shown in UI

  // ── Getters ────────────────────────────────────────────────────────────────
  ExamPaper?     get primaryPaper      => _primaryPaper;
  ExamPaper?     get backupPaper       => _backupPaper;
  FairnessReport? get fairnessReport   => _fairnessReport;
  GenerationStep get step              => _step;
  bool           get isGenerating      => _isGenerating;
  bool           get isSealing         => _isSealing;
  bool           get isRunningOcr      => _isRunningOcr;
  bool           get isUnlocked        => _isUnlocked;
  double         get generationProgress => _generationProgress;
  String         get currentSeed       => _currentSeed;
  List<String>   get seedComponents    => _seedComponents;

  bool get hasPaper  => _primaryPaper != null;
  bool get hasBackup => _backupPaper != null;

  // ── Paper generation ───────────────────────────────────────────────────────

  Future<void> generatePaper(List<RawQuestion> rawPool) async {
    if (_isGenerating) return;
    _isGenerating = true;
    _generationProgress = 0.0;
    _step = GenerationStep.collectingKeys;
    notifyListeners();

    await Future.delayed(const Duration(milliseconds: 600));

    // Step 1: Collect setter public keys
    _step = GenerationStep.computingSeed;
    _generationProgress = 0.2;

    // Compute per-setter XOR components (for UI visualization)
    _seedComponents = allSetterProfiles.map((s) {
      final hash = s.publicKeyBytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join();
      return hash.substring(0, 16).toUpperCase();
    }).toList();

    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 800));

    // Compute actual seed
    final publicKeys = allSetterProfiles.map((s) => s.publicKeyBytes).toList();
    _currentSeed = CryptoService.generatePaperSeed(publicKeys);
    _generationProgress = 0.4;
    notifyListeners();

    await Future.delayed(const Duration(milliseconds: 600));

    // Step 2: Shuffle
    _step = GenerationStep.shuffling;
    _generationProgress = 0.6;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 1000));

    // Step 3: Assemble
    _step = GenerationStep.assembling;
    _generationProgress = 0.8;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 600));

    // Step 4: Sign
    _step = GenerationStep.signing;
    _generationProgress = 0.9;
    notifyListeners();
    await Future.delayed(const Duration(milliseconds: 500));

    // Build the paper
    final paperQuestions = PaperGeneratorService.toPaperQuestions(rawPool);
    _primaryPaper = PaperGeneratorService.buildPaper(
      paperId: 'PAPER-${_uuid.v4().substring(0, 8).toUpperCase()}',
      title: 'Final Examination Paper',
      subjectCode: 'MULTI',
      subjectName: 'Multi-Subject',
      allPaperQuestions: paperQuestions,
      hexSeed: _currentSeed,
      setterFingerprints: allSetterProfiles
          .map((s) => CryptoService.keyFingerprint(s.publicKeyBytes))
          .toList(),
      questionCount: kQuestionsPerPaper,
    );

    _step = GenerationStep.done;
    _generationProgress = 1.0;
    _isGenerating = false;
    _backupPaper = null;
    _fairnessReport = null;
    _isUnlocked = false;
    notifyListeners();
  }

  // ── Seal paper ─────────────────────────────────────────────────────────────

  Future<void> sealPaper() async {
    if (_primaryPaper == null || _isSealing) return;
    _isSealing = true;
    notifyListeners();

    await Future.delayed(const Duration(milliseconds: 800));

    final newCustody = List<CustodyEntry>.from(_primaryPaper!.chainOfCustody)
      ..add(CustodyEntry(
        action: 'Paper Sealed',
        actorName: 'Admin Controller',
        actorRole: 'admin',
        timestamp: DateTime.now(),
        details: 'SHA-256 signature verified. Paper locked for dispatch.',
      ));

    _primaryPaper = _primaryPaper!.copyWith(
      status: PaperStatus.sealed,
      chainOfCustody: newCustody,
    );
    _isSealing = false;
    notifyListeners();
  }

  // ── OCR fairness ───────────────────────────────────────────────────────────

  Future<void> runOcrCheck() async {
    if (_primaryPaper == null || _isRunningOcr) return;
    _isRunningOcr = true;
    notifyListeners();

    _fairnessReport = await OcrSimulatorService.runFairnessCheck(
      questions: _primaryPaper!.questions,
      topicBreakdown: _primaryPaper!.topicBreakdown,
      difficultyBreakdown: _primaryPaper!.difficultyBreakdown,
    );

    _isRunningOcr = false;
    notifyListeners();
  }

  // ── Print center unlock ────────────────────────────────────────────────────

  Future<void> dispatchPaper() async {
    if (_primaryPaper == null) return;
    final newCustody = List<CustodyEntry>.from(_primaryPaper!.chainOfCustody)
      ..add(CustodyEntry(
        action: 'Dispatched to Print Center',
        actorName: 'Admin Controller',
        actorRole: 'admin',
        timestamp: DateTime.now(),
        details: 'Encrypted packet transmitted over secure channel.',
      ));
    _primaryPaper = _primaryPaper!.copyWith(
      status: PaperStatus.dispatched,
      chainOfCustody: newCustody,
    );
    notifyListeners();
  }

  Future<void> unlockPaper() async {
    if (_primaryPaper == null) return;
    await Future.delayed(const Duration(milliseconds: 600));

    final newCustody = List<CustodyEntry>.from(_primaryPaper!.chainOfCustody)
      ..add(CustodyEntry(
        action: 'Paper Decrypted at Print Center',
        actorName: 'Print Center Officer',
        actorRole: 'printOfficer',
        timestamp: DateTime.now(),
        details: 'OTP + Biometric verified. Paper decrypted for printing.',
      ));
    _primaryPaper = _primaryPaper!.copyWith(chainOfCustody: newCustody);
    _isUnlocked = true;
    notifyListeners();
  }

  Future<void> markPrinted() async {
    if (_primaryPaper == null) return;
    final newCustody = List<CustodyEntry>.from(_primaryPaper!.chainOfCustody)
      ..add(CustodyEntry(
        action: 'Paper Printed',
        actorName: 'Print Center Officer',
        actorRole: 'printOfficer',
        timestamp: DateTime.now(),
        details: 'Physical copies printed and logged. Digital copy purged.',
      ));
    _primaryPaper = _primaryPaper!.copyWith(
      status: PaperStatus.printed,
      chainOfCustody: newCustody,
    );
    notifyListeners();
  }

  // ── Backup paper ───────────────────────────────────────────────────────────

  Future<void> generateBackupPaper(List<RawQuestion> rawPool) async {
    if (_primaryPaper == null || _isGenerating) return;
    _isGenerating = true;
    notifyListeners();

    await Future.delayed(const Duration(milliseconds: 800));

    const salt = 'BACKUP_SALT_2026';
    final backupSeed = CryptoService.generateBackupSeed(_currentSeed, salt);
    final paperQuestions = PaperGeneratorService.toPaperQuestions(rawPool);

    _backupPaper = PaperGeneratorService.buildPaper(
      paperId: 'BACKUP-${_uuid.v4().substring(0, 8).toUpperCase()}',
      title: 'BACKUP — Final Examination Paper',
      subjectCode: 'MULTI',
      subjectName: 'Multi-Subject',
      allPaperQuestions: paperQuestions,
      hexSeed: backupSeed,
      setterFingerprints: allSetterProfiles
          .map((s) => CryptoService.keyFingerprint(s.publicKeyBytes))
          .toList(),
      questionCount: kQuestionsPerPaper,
      isBackup: true,
      backupSalt: salt,
    );

    // Auto-seal the backup
    final newCustody = List<CustodyEntry>.from(_backupPaper!.chainOfCustody)
      ..add(CustodyEntry(
        action: 'Backup Paper Sealed',
        actorName: 'Admin Controller',
        actorRole: 'admin',
        timestamp: DateTime.now(),
        details: 'Alternate seed derived: backup salt applied to primary seed.',
      ));
    _backupPaper = _backupPaper!.copyWith(
      status: PaperStatus.sealed,
      chainOfCustody: newCustody,
    );

    _isGenerating = false;
    notifyListeners();
  }

  void reset() {
    _primaryPaper = null;
    _backupPaper = null;
    _fairnessReport = null;
    _step = GenerationStep.idle;
    _isGenerating = false;
    _isSealing = false;
    _isRunningOcr = false;
    _isUnlocked = false;
    _generationProgress = 0.0;
    _currentSeed = '';
    _seedComponents = [];
    notifyListeners();
  }
}
