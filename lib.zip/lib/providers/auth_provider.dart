import 'package:flutter/foundation.dart';
import '../models/user_role.dart';
import '../models/setter_profile.dart';
import '../data/dummy_questions.dart';

class AuthProvider extends ChangeNotifier {
  UserRole? _currentRole;
  SetterProfile? _currentSetterProfile;
  bool _biometricVerified = false;
  bool _isAnimatingBiometric = false;
  double _biometricProgress = 0.0;

  // ── Getters ────────────────────────────────────────────────────────────────
  UserRole?      get currentRole         => _currentRole;
  SetterProfile? get currentSetterProfile => _currentSetterProfile;
  bool           get isLoggedIn          => _currentRole != null && _biometricVerified;
  bool           get biometricVerified   => _biometricVerified;
  bool           get isAnimatingBiometric => _isAnimatingBiometric;
  double         get biometricProgress   => _biometricProgress;

  String get actorId   => _currentSetterProfile?.id ?? _currentRole?.name ?? 'system';
  String get actorName => _currentSetterProfile?.name ?? _currentRole?.displayName ?? 'System';
  String get actorRole => _currentRole?.shortName ?? 'system';

  // ── Setter-specific login ──────────────────────────────────────────────────
  /// Returns a list of available setter profiles for selection
  List<SetterProfile> get availableSetters => allSetterProfiles;

  /// Log in as a specific setter
  void loginAsSetter(SetterProfile profile) {
    _currentRole = UserRole.setter;
    _currentSetterProfile = profile;
    _biometricVerified = true;
    notifyListeners();
  }

  // ── Generic role login ─────────────────────────────────────────────────────
  void setRole(UserRole role) {
    _currentRole = role;
    if (role == UserRole.setter) {
      // Setter must also pick a profile — handled separately
      _currentSetterProfile = null;
    } else {
      _currentSetterProfile = null;
    }
    _biometricVerified = false;
    _biometricProgress = 0.0;
    notifyListeners();
  }

  void setBiometricProgress(double progress) {
    _biometricProgress = progress;
    notifyListeners();
  }

  void setBiometricAnimating(bool animating) {
    _isAnimatingBiometric = animating;
    notifyListeners();
  }

  void completeBiometric() {
    _biometricVerified = true;
    _biometricProgress = 1.0;
    _isAnimatingBiometric = false;
    notifyListeners();
  }

  void logout() {
    _currentRole = null;
    _currentSetterProfile = null;
    _biometricVerified = false;
    _biometricProgress = 0.0;
    _isAnimatingBiometric = false;
    notifyListeners();
  }
}
