import 'package:flutter/foundation.dart';
import 'package:uuid/uuid.dart';
import '../models/question.dart';
import '../models/setter_profile.dart';
import '../services/crypto_service.dart';
import '../data/dummy_questions.dart';

class QuestionProvider extends ChangeNotifier {
  final _uuid = const Uuid();

  /// Encrypted question blobs, keyed by question ID
  final Map<String, EncryptedQuestion> _encryptedQuestions = {};

  /// Map from setterId to their submitted question ids (for display grouping)
  final Map<String, List<String>> _questionsBySetterLocal = {};

  /// Keep raw questions in memory for admin to decrypt (demo only)
  /// In a real system only ciphertexts would be stored
  final Map<String, RawQuestion> _rawQuestions = {};

  bool _isEncrypting = false;
  String _lastEncryptedId = '';

  // ── Getters ────────────────────────────────────────────────────────────────
  List<EncryptedQuestion> get allEncryptedQuestions =>
      _encryptedQuestions.values.toList();

  List<EncryptedQuestion> questionsForSetter(String setterId) =>
      _encryptedQuestions.values
          .where((q) => q.setterId == setterId)
          .toList();

  int get totalCount => _encryptedQuestions.length;
  bool get isEncrypting => _isEncrypting;
  String get lastEncryptedId => _lastEncryptedId;

  Map<String, int> get countBySetter {
    final map = <String, int>{};
    for (final q in _encryptedQuestions.values) {
      map[q.setterId] = (map[q.setterId] ?? 0) + 1;
    }
    return map;
  }

  // ── Encryption & submission ────────────────────────────────────────────────

  /// Encrypt and store a single raw question
  Future<void> submitQuestion(
    RawQuestion question,
    SetterProfile setterProfile,
  ) async {
    _isEncrypting = true;
    notifyListeners();

    final payload = await CryptoService.encryptQuestion(
      question,
      setterProfile.privateKeyBytes,
    );

    final encrypted = EncryptedQuestion(
      id: question.id,
      setterId: question.setterId,
      setterName: question.setterName,
      subjectCode: question.subjectCode,
      subjectName: question.subjectName,
      topic: question.topic,
      difficulty: question.difficulty,
      setterKeyFingerprint: CryptoService.keyFingerprint(
        setterProfile.publicKeyBytes,
      ),
      submittedAt: DateTime.now(),
      ciphertext: payload.ciphertext,
      nonce: payload.nonce,
      mac: payload.mac,
      wrappedKey: payload.wrappedKey,
    );

    _encryptedQuestions[question.id] = encrypted;
    _rawQuestions[question.id] = question;

    _questionsBySetterLocal
        .putIfAbsent(question.setterId, () => [])
        .add(question.id);

    _lastEncryptedId = question.id;
    _isEncrypting = false;
    notifyListeners();
  }

  /// Load all sample questions for a given setter profile (batch encrypt)
  Future<void> loadSampleQuestions(SetterProfile setterProfile) async {
    final rawList = allDummyQuestions[setterProfile.id] ?? [];
    for (final raw in rawList) {
      if (!_encryptedQuestions.containsKey(raw.id)) {
        await submitQuestion(raw, setterProfile);
        // Small yield to allow UI to update
        await Future.delayed(const Duration(milliseconds: 50));
      }
    }
  }

  /// Decrypt a question for admin display (requires setter private key)
  Future<RawQuestion?> decryptQuestion(
    EncryptedQuestion encrypted,
    List<int> setterPrivateKey,
  ) async {
    try {
      final payload = EncryptedPayload(
        ciphertext: encrypted.ciphertext,
        nonce: encrypted.nonce,
        mac: encrypted.mac,
        wrappedKey: encrypted.wrappedKey,
      );
      final json = await CryptoService.decryptQuestion(payload, setterPrivateKey);
      return RawQuestion(
        id: json['id'] as String,
        subjectCode: json['subjectCode'] as String,
        subjectName: json['subjectName'] as String,
        topic: json['topic'] as String,
        text: json['text'] as String,
        options: List<String>.from(json['options'] as List),
        correctAnswerIndex: json['correctAnswerIndex'] as int,
        difficulty: QuestionDifficulty.values
            .firstWhere((d) => d.name == json['difficulty']),
        setterId: json['setterId'] as String,
        setterName: json['setterName'] as String,
      );
    } catch (_) {
      return null;
    }
  }

  /// Get raw question for paper assembly (admin-only in demo)
  RawQuestion? getRaw(String id) => _rawQuestions[id];

  /// Get all raw questions for paper generation
  List<RawQuestion> getAllRaw() => _rawQuestions.values.toList();

  void clear() {
    _encryptedQuestions.clear();
    _rawQuestions.clear();
    _questionsBySetterLocal.clear();
    notifyListeners();
  }
}
