import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

import 'providers/auth_provider.dart';
import 'providers/audit_provider.dart';
import 'providers/question_provider.dart';
import 'providers/paper_provider.dart';

import 'screens/landing_screen.dart';
import 'screens/role_select_screen.dart';
import 'screens/biometric_gate_screen.dart';
import 'screens/setter_portal_screen.dart';
import 'screens/admin_dashboard_screen.dart';
import 'screens/paper_generation_screen.dart';
import 'screens/security_monitor_screen.dart';
import 'screens/print_center_screen.dart';
import 'screens/backup_paper_screen.dart';

import 'theme/app_theme.dart';

void main() {
  runApp(const SecureExamApp());
}

// ── Router ─────────────────────────────────────────────────────────────────

final _router = GoRouter(
  initialLocation: '/',
  routes: [
    GoRoute(
      path: '/',
      builder: (context, state) => const LandingScreen(),
    ),
    GoRoute(
      path: '/role-select',
      builder: (context, state) => const RoleSelectScreen(),
    ),
    GoRoute(
      path: '/biometric/:role',
      builder: (context, state) => BiometricGateScreen(
        roleName: state.pathParameters['role'] ?? 'setter',
      ),
    ),
    // ── Setter routes ──────────────────────────────────────────────────────
    GoRoute(
      path: '/setter',
      builder: (context, state) => const SetterPortalScreen(),
    ),
    // ── Admin routes ───────────────────────────────────────────────────────
    GoRoute(
      path: '/admin',
      builder: (context, state) => const AdminDashboardScreen(),
    ),
    GoRoute(
      path: '/admin/generate',
      builder: (context, state) => const PaperGenerationScreen(),
    ),
    GoRoute(
      path: '/admin/security',
      builder: (context, state) => const SecurityMonitorScreen(),
    ),
    GoRoute(
      path: '/admin/backup',
      builder: (context, state) => const BackupPaperScreen(),
    ),
    // ── Print officer routes ───────────────────────────────────────────────
    GoRoute(
      path: '/print',
      builder: (context, state) => const PrintCenterScreen(),
    ),
  ],
);

// ── Root app ───────────────────────────────────────────────────────────────

class SecureExamApp extends StatelessWidget {
  const SecureExamApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => AuditProvider()),
        ChangeNotifierProvider(create: (_) => QuestionProvider()),
        ChangeNotifierProvider(create: (_) => PaperProvider()),
      ],
      child: MaterialApp.router(
        title: 'SecureExam — Safe Question Paper System',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.dark,
        routerConfig: _router,
      ),
    );
  }
}
